package com.t3h.project;


import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

public class NewMovie extends Activity {
	private ListView lvNewMovie;
	
    public void onCreate(Bundle savedInstanceState) {
    	
    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_new_movie);
        
        lvNewMovie = (ListView) findViewById(R.id.lvNewMovie);
//        lvNewMovie.setAdapter(rows);

    }

}
