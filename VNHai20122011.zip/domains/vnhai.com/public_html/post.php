<?php
if (!defined('IN_MEDIA')) die("Hack");
if ($_POST['request']) {
    if (isFloodPost($_SESSION['prev_post'])) {
			echo '<p align="center"><b>Bạn cần phải chờ thêm '.$wait_post.' giây nữa để có thể gửi thêm YÊU CẦU</b></p>';
		exit();
	}
	$warn = '';
	$request_email = bad_words($_POST['request_email']);
	$request_name = bad_words($_POST['request_name']);
	if ($request_name == "Tên bộ phim mà bạn muốn xem (vui lòng gõ tiếng việt có dấu)" || $request_email == "Nick yahoo của bạn" || $request_name == "" || $request_email == ""){
	        echo '<p align="center"><b>YÊU CẦU của bạn không đúng</b></p>';
		exit();
	 }
	elseif ($request_email && $request_name){
	$mysql->query("INSERT INTO ".$tb_prefix."request (request_email,request_name) VALUES ('".$request_email."','".$request_name."')");
	}
	else{ 
	     $warn = "Bạn chưa nhập cảm nhận hoặc tên người gửi";
	}
	if ($warn) echo "<b>Lỗi :</b> ".$warn;
	else echo "OK";
	$_SESSION['prev_message_post'] = time();
	exit();
}

elseif ($_POST['rating']) {
	$id = (int)$_POST['film_id'];
	$star = (int)$_POST['star'];
	$mysql->query("UPDATE ".$tb_prefix."film SET film_rating = film_rating+$star, film_rating_total = film_rating_total+1, film_rate = film_rating / film_rating_total WHERE film_id = $id");
	$q = $mysql->query("SELECT * FROM ".$tb_prefix."film WHERE film_id = $id");
	$q = $mysql->fetch_array($q);
	rating_img($q['film_rating'],$q['film_rating_total']);
	$rater_stars_img = $r_s_img;
	$rater_stars_img="";
	echo $rater_stars_img."<br><b><font color=\"#F5AA59\" size=\"2\">".$q['film_rating']." Star | ".$q['film_rating_total']." Rates</b></font>";
}

elseif ($_POST['broken']) {
	$film_id = (int)$_POST['film_id'];
    $episode_id = (int)$_POST['episode_id'];
	$htm = $temp->get_htm('broken');	
	$mysql->query("UPDATE ".$tb_prefix."film SET film_broken = 1 WHERE film_id = $film_id");
    $mysql->query("UPDATE ".$tb_prefix."episode SET episode_broken = 1 WHERE episode_id = $episode_id");
	$main = $temp->replace_value($htm,array(
					'broken.IMG'	=>	'images/music.gif',
					'broken.THANKS'	=>	'<B>CẢM ƠN BẠN ĐÃ THÔNG BÁO. CHÚNG TÔI SẼ UPDATE LINK NGAY KHI CÓ THỂ</B>',
				)
			);
  echo $main;
 exit();
}

elseif ($_POST['comment']) {
    if (isFloodPost($_SESSION['prev_post'])) {
			echo '<p align="center"><img src=images/warning.gif width=100 height=100><br><b>Bạn cần phải chờ thêm '.$wait_post.' giây nữa để có thể gửi thêm CẢM NHẬN.</b></p>';
		exit();
	 }
	 $warn = '';
	 if (!$isLoggedIn){
		 $comment_imgpass = $_POST['comment_img'];
		 if ($comment_imgpass!=$_SESSION['comment_img_pass']){
			echo "<i><b>Hãy <a href='./members/login.html'>đăng nhập</a> trước khi viết cảm nhận. Nếu bạn chưa có tài khoản, hãy <a href='./members/register.html'>đăng ký</a> ngay một tài khoản để sử dụng, hoặc nhập đúng mã số hiện trong ảnh để có thể đăng cảm nhận của bạn về phim này.</b></i><br/>";
		exit();
		 }else $comment_poster = $_POST['comment_poster'];
	}else $comment_poster = $_SESSION['user_name'];
	
	$film_id = (int)$_POST['film_id'];
	$comment_content = $_POST['comment_content'];
	if ($comment_poster == UNIstr("Tên của bạn") || $comment_poster == "" || $comment_content == ""){
	        echo '<p align="center"><b>CẢM NHẬN của bạn không đúng QUY ĐỊNH</b></p>';
		exit();
	 }
	elseif ($film_id && $comment_poster && $comment_content){
	$mysql->query("INSERT INTO ".$tb_prefix."comment (comment_film,comment_poster,comment_content,comment_time) VALUES ('".$film_id."','".$comment_poster."','".$comment_content."','".NOW."')");
	}
	else{ 
	     $warn = "Bạn chưa nhập cảm nhận hoặc tên người gửi";
	}
	if ($warn) echo "<b>Lỗi :</b> ".$warn;
	else echo "OK";
	$_SESSION['prev_message_post'] = time();
	exit();
}
?>