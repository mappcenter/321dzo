<?php
define('IN_MEDIA',true);
require('inc/_config.php');
require_once('inc/_functions.php');

$rssVersion = 2.0;
$cat = (int) $_GET['c'];

if(empty($cat)) {
	$query = "SELECT * FROM ".$tb_prefix."film ORDER BY film_id DESC LIMIT 10";
}
elseif(!empty($cat) && is_numeric($cat)) { 
	$query = "SELECT * FROM ".$tb_prefix."film WHERE film_cat =$cat ORDER BY film_id DESC LIMIT 10";
}
function clean_feed($input) {
	$original = array("<", ">", "&", '"');
	$replaced = array("&lt;", "&gt;", "&amp;", "&quot;");
	$newinput = str_replace($original, $replaced, $input);
	return $newinput;
}
function generateFeed ( $homeURL, $title, $version = '2.0', $query) {
global $mysql, $cat, $tb_prefix;
// a little check for the arguments thrown in.
if (func_num_args() < 2)
exit ("Insufficant Parameters");
// only select the columns you need, thus reducing the work the DBMS has to do.
// execute the query
$results = mysql_query ($query) or exit(mysql_error());

// check for the number of rows returned before doing any further actions.
if (mysql_num_rows ($results) == 0){
exit("Nothing to show.");
}
else {
// Get category name
	if(!empty($cat) && is_numeric($cat)) { 
		$query = mysql_query("SELECT * FROM ".$tb_prefix."film WHERE film_cat='".$cat."'");
		$result = mysql_fetch_array($query);
	}

$rss = "";
// tell the browser we want xml output by setting the following header.
header("Content-Type: text/html; charset=utf-8");
$rss .= "<html><head>\r\n";
$rss .= "<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\"></head>\r\n";
$rss .= "<body>\r\n";
$rss .= "<table style=\"width: 100%;\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"> \r\n";
$rss .= "<link>" . $homeURL . "</link>\r\n";
$rss .= "<description>KGT! Movie | The Gioi Giai Tri</description>\r\n";
$rss .= "<language>vi-vn</language>\r\n";
$rss .= "<copyright>Copyright (C) " . ucwords($title) . "</copyright>\r\n";
$rss .= "<ttl>60</ttl>\r\n";
$rss .= "<generator>KGT! Movie</generator> \r\n";

while ($row = mysql_fetch_array($results)){
	$m_time = date('D, d M Y H:i:s');
	$rss .= "<item>\r\n";
	$rss .= "<title>" . clean_feed($row['film_name']) . "</title>\r\n";
	$rss .= "<description>" . clean_feed($row['film_actor']) . " - " .clean_feed($row['film_director']) . " - " .clean_feed($row['film_area'])."</description>\r\n";
	$rss .= "<link>".$homeURL."/info/".$row['film_id']."/".clean_feed(replace($row['film_name_ascii']))."</link>\r\n";
	$rss .= "<pubDate>".$m_time." GMT</pubDate>\r\n";
	$rss .= "</item>\r\n\r\n";
}

$rss .= "</channel>\r\n";
$rss .= "</rss>\r\n";

echo $rss;
}
}
// call the function with all our settings from the top of the script
//generateFeed( $web_link , $web_title, $rssVersion, $query );

?>