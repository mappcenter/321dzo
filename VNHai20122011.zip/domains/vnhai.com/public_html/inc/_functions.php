﻿<?php
if (!defined('IN_MEDIA')) die("Hack");
function rating_img($rate,$rate_tt) {
   	global $r_s_img;
	if ($rate_tt =='0') $rating = 0;
	else $rating = $rate / $rate_tt;
	if ($rating <= 0  ){$star1 = "none"; $star2 = "none"; $star3 = "none"; $star4 = "none"; $star5 = "none";}
	if ($rating >= 0.5){$star1 = "half"; $star2 = "none"; $star3 = "none"; $star4 = "none"; $star5 = "none";}
	if ($rating >= 1  ){$star1 = "full"; $star2 = "none"; $star3 = "none"; $star4 = "none"; $star5 = "none";}
	if ($rating >= 1.5){$star1 = "full"; $star2 = "half"; $star3 = "none"; $star4 = "none"; $star5 = "none";}
	if ($rating >= 2  ){$star1 = "full"; $star2 = "full"; $star3 = "none"; $star4 = "none"; $star5 = "none";}
	if ($rating >= 2.5){$star1 = "full"; $star2 = "full"; $star3 = "half"; $star4 = "none"; $star5 = "none";}
	if ($rating >= 3  ){$star1 = "full"; $star2 = "full"; $star3 = "full"; $star4 = "none"; $star5 = "none";}
	if ($rating >= 3.5){$star1 = "full"; $star2 = "full"; $star3 = "full"; $star4 = "half"; $star5 = "none";}
	if ($rating >= 4  ){$star1 = "full"; $star2 = "full"; $star3 = "full"; $star4 = "full"; $star5 = "none";}
	if ($rating >= 4.5){$star1 = "full"; $star2 = "full"; $star3 = "full"; $star4 = "full"; $star5 = "half";}
	if ($rating >= 5  ){$star1 = "full"; $star2 = "full"; $star3 = "full"; $star4 = "full"; $star5 = "full";}		
	$r_s_img = 	"<img src=\"http://vnhai.com/".$_SESSION['skin_folder']."/img/rate/".$star1.".gif\" width=\"15px\">"
						." <img src=\"http://vnhai.com/".$_SESSION['skin_folder']."/img/rate/".$star2.".gif\" width=\"15px\">"
						." <img src=\"http://vnhai.com/".$_SESSION['skin_folder']."/img/rate/".$star3.".gif\" width=\"15px\">"
						." <img src=\"http://vnhai.com/".$_SESSION['skin_folder']."/img/rate/".$star4.".gif\" width=\"15px\">"
						." <img src=\"http://vnhai.com/".$_SESSION['skin_folder']."/img/rate/".$star5.".gif\" width=\"15px\">";
}

function m_setcookie($name, $value = '', $permanent = true) {
	global $web_link;
	$setCookieType=1;	
	$expire = ($permanent)?(time() + 60 * 60 * 24 * 365):0;
	
	if ($setCookieType == 1) {
		$url = $web_link;
		if ($url[strlen($url)-1] != '/') $url .= '/';
		$secure = (($_SERVER['HTTPS'] == 'on' OR $_SERVER['HTTPS'] == '1') ? true : false);
		$p = parse_url($url);
		$path = !empty($p['path']) ? $p['path'] : '/';
		$domain = $p['host'];
		if (substr_count($domain, '.') > 1) {
			while (substr_count($domain, '.') > 1)
			{
				$pos = strpos($domain, '.');
				$domain = substr($domain, $pos + 1);
			}
			
		}
		else $domain = '';
		@setcookie($name, $value, $expire, $path, $domain, $secure);
	}
	else @setcookie($name,$value,$expire);
}
function m_checkLogin(){
	global $mysql, $tb_prefix;
	
	if ($_COOKIE['USER']) {
		$identifier = $_COOKIE['USER'];
		$q = $mysql->query("SELECT user_identifier, user_id, user_name FROM ".$tb_prefix."user WHERE user_identifier = '".$identifier."'");
		if ($mysql->num_rows($q)) {
			$r = $mysql->fetch_array($q);
			$_SESSION['user_id'] = $r['user_id'];
			$_SESSION['user_name'] = $r['user_name'];
			$return = true;
		}
		else $return = false;
	}
	else $return = false;
	return $return;
}

function get_total($table,$f1,$f2 = '') {
	global $mysql, $tb_prefix;
	$q = "SELECT COUNT($f1) FROM ".$tb_prefix.$table;
	$q .= ($f2)?" ".$f2:'';
	$tt = $mysql->fetch_array($mysql->query($q));
	return $tt[0];
}
function m_check_random_str($str,$len = 5) {
	if (!ereg('^([A-Za-z0-9]){'.$len.'}$',$str)) return false;
	return true;
}
function replace($str) {
	$str = trim($str);
	$str = str_replace('%20', '-', $str);
	$str = str_replace(':', '', $str);
	$str = str_replace('!', '', $str);
	$str = str_replace('/', '-', $str);
	$str = str_replace(' ', '-', $str);
	return $str.".html";
}

function check_img($img) {
	if ($img == '') $img = $_SESSION['skin_folder']."/img/no_img.gif";
	return $img;
}

function check_data($name) {
	if ($name == '') $name = "Đang cập nhật";
	return $name;
}

function text_tidy($string) {
	$string = str_replace ( '&amp;', '&', $string );
	$string = str_replace ( "'", "'", $string );
	$string = str_replace ( '&quot;', '"', $string );
	$string = str_replace ( '&lt;', '<', $string );
	$string = str_replace ( '&gt;', '>', $string );
	return $string;
}
function splitlink($name,$type, $class) {

	global $web_link,$lang_no;

	if ($name == '' || $name== $lang_no) $name = $lang_no;

	else

	{
		$name = str_replace(', ', ',', $name);
		$name = str_replace(',', ', ', $name);
		$dem = explode(', ',$name);

		$d=count($dem);

		for($i=0; $i<$d-1;$i++) {

		$fas= $fas.'<a href="'.$web_link.'/'.$type.'/'.replacesearch($dem[$i]).'.html" style="text-decoration:none;" class="'.$class.'">'.$dem[$i].'</a>, ';					}

	    $name = $fas.'<a href="'.$web_link.'/'.$type.'/'.replacesearch($dem[$d-1]).'.html" style="text-decoration:none;" class="'.$class.'">'.$dem[$d-1].'</a>';


	}

	return $name;

}
function replacesearch($str) {
	$str = str_replace('%20', '+', $str);
	$str = str_replace('...', '', $str);
	$str = str_replace(' ', '+', $str);
	
	
	return $str;
}
function cut_string($str,$len) {
	if ($str=='' || $str==NULL) return $str;
	if (is_array($str)) return $str;
	$str = trim($str);
	if (strlen($str) <= $len) return $str;
	$str = substr($str,0,$len);
	$str = $str.' ...';
	return $str;
}

function get_words($str,$num)
{
	$limit = $num - 1 ;
    $str_tmp = '';
    $arrstr = explode(" ", $str);
    if ( count($arrstr) <= $num ) { return $str; }
    if (!empty($arrstr))
    {
        for ( $j=0; $j< count($arrstr) ; $j++)    
        {
            $str_tmp .= " " . $arrstr[$j];
            if ($j == $limit) 
            {
                break;
            }
        }
    }
    return $str_tmp.' ...';
}
function check_str_old($a){
$n=intval(strlen($a)/21);
if($n>0)
{
for($i=1;$i<=$n;$i++)
{
$b=$b.substr($a,0,21)." ";
$a=substr($a,21,strlen($a));
}
}
else
{
$b=$a;
}
return $b;
}
function check_str($str) {$str2 = explode(' ',$str);$count = count($str2);for ($i= 0; $i < $count ; $i++){if(strlen($str2[$i]) < 10){$result .= $str2[$i].' ';continue;}$str3 = substr($str2[$i],0,10);$result .= $str3.' ';}return $result;}
function bad_words($str) {
	$chars = array('địt','Địt','ĐỊT','đéo','Đéo','ĐÉO','lồn','Lồn','LỒN','cặc','Cặc','CẶC','dái','Dái','DÁI','chó','Chó','CHÓ','Cứt','cứt','CỨT','ỉa','Ỉa','đái','Đái','ỈA');
	foreach ($chars as $key => $arr)
		$str = preg_replace( "/(^|\b)".$arr."(\b|!|\?|\.|,|$)/i", "***", $str ); 
		$str = wordwrap($str, 23, " ", true);
		$str = str_replace('<','&lt;',$str);
		$str = check_str($str);
	return $str;
}

function un_htmlchars($str) {
	return str_replace(array('&lt;', '&gt;', '&quot;', '&amp;', '&#92;', '&#39'), array('<', '>', '"', '&', chr(92), chr(39)), $str );
}

function htmlchars($str) {
	return str_replace(
		array('&', '<', '>', '"', chr(92), chr(39)),
		array('&amp;', '&lt;', '&gt;', '&quot;', '&#92;', '&#39'),
		$str
	);
}

function get_ascii($str) {
	$chars = array(
		'a'	=>	array('ấ','ầ','ẩ','ẫ','ậ','Ấ','Ầ','Ẩ','Ẫ','Ậ','ắ','ằ','ẳ','ẵ','ặ','Ắ','Ằ','Ẳ','Ẵ','Ặ','á','à','ả','ã','ạ','â','ă','Á','À','Ả','Ã','Ạ','Â','Ă'),
		'e' =>	array('ế','ề','ể','ễ','ệ','Ế','Ề','Ể','Ễ','Ệ','é','è','ẻ','ẽ','ẹ','ê','É','È','Ẻ','Ẽ','Ẹ','Ê'),
		'i'	=>	array('í','ì','ỉ','ĩ','ị','Í','Ì','Ỉ','Ĩ','Ị'),
		'o'	=>	array('ố','ồ','ổ','ỗ','ộ','Ố','Ồ','Ổ','Ô','Ộ','ớ','ờ','ở','ỡ','ợ','Ớ','Ờ','Ở','Ỡ','Ợ','ó','ò','ỏ','õ','ọ','ô','ơ','Ó','Ò','Ỏ','Õ','Ọ','Ô','Ơ'),
		'u'	=>	array('ứ','ừ','ử','ữ','ự','Ứ','Ừ','Ử','Ữ','Ự','ú','ù','ủ','ũ','ụ','ư','Ú','Ù','Ủ','Ũ','Ụ','Ư'),
		'y'	=>	array('ý','ỳ','ỷ','ỹ','ỵ','Ý','Ỳ','Ỷ','Ỹ','Ỵ'),
		'd'	=>	array('đ','Đ'),
	);
	foreach ($chars as $key => $arr) 
		foreach ($arr as $val)
			$str = str_replace($val,$key,$str);
	return $str;
}

function emotions_array() {
	return array(
		6 => '>:D<',		18 => '#:-S',				36 => '<:-P',		42 => ':-SS',
		48 => '<):)',		50 => '3:-O',				51 => ':(|)',		53 => '@};-',
		55 => '**==',		56 => '(~~)',				58 => '*-:)',		63 => '[-O<',
		67 => ':)>-',		77 => '^:)^',				106 => ':-??',		25 => 'O:)',
		26 => ':-B',		28 => 'I-)',				29 => '8-|',		30 => 'L-)',
		31 => ':-&',		32 => ':-$',				33 => '[-(',		34 => ':O)',
		35 => '8-}',		7 => ':-/',					37 => '(:|',		38 => '=P~',
		39 => ':-?',		40 => '#-O',				41 => '=D>',		9 => ':">',
		43 => '@-)',		44 => ':^O',				45 => ':-W',		46 => ':-<',
		47 => '>:P',		11 => array(':*',':-*'),	49 => ':@)',		12 => '=((',
		13 => ':-O',		52 => '~:>',				16 => 'B-)',		54 => '%%-',
		17 => ':-S',		5 => ';;)',					57 => '~O)',		19 => '>:)',
		59 => '8-X',		60 => '=:)',				61 => '>-)',		62 => ':-L',
		20 => ':((',		64 => '$-)',				65 => ':-"',		66 => 'B-(',
		21 => ':))',		68 => '[-X',				69 => '\:D/',		70 => '>:/',
		71 => ';))',		72 => 'O->',				73 => 'O=>',		74 => 'O-+',
		75 => '(%)',		76 => ':-@',				23 => '/:)',		78 => ':-J',
		79 => '(*)',		100 => ':)]',				101 => ':-C',		102 => '~X(',
		103 => ':-H',		104 => ':-T',				105 => '8->',		24 => '=))',
		107 => '%-(',		108 => ':O3',				1 => array(':)',':-)'),		2 => array(':(',':-('),
		3 => array(';)',';-)'),		22 => array(':|',':-|'),		14 => array('X(','X-('),		15 => array(':>',':->'),
		8 => array(':X',':-X'),		4 => array(':D',':-D'),		27 => '=;',		10 => array(':P',':-P'),
	);
}

function emotions_replace($s) {
	$emotions = emotions_array();
	foreach ($emotions as $a => $b) {
		$x = array();
		if (is_array($b)) {
			for ($i=0;$i<count($b);$i++) {
				$b[$i] = htmlchars($b[$i]);
				$x[] = $b[$i];
				$v = strtolower($b[$i]);
				if ($v != $b[$i]) $x[] = $v;
				}
		}
		else {
			$b = htmlchars($b);
			$x[] = $b;
			$v = strtolower($b);
			if ($v != $b) $x[] = $v;
		}
		$p = '';
		for ($u=0;$u<strlen($x[0]);$u++) {
			$ord = ord($x[0][$u]);
			if ($ord < 65 && $ord > 90) $p .= '&#'.$ord.';';
			else $p .= $x[0][$u];
		}
		$s = str_replace($x,'<img src="images/emoticons/'.$a.'.gif" />',$s); 
			
	}
	return $s;
}

function isFloodPost(){
	$_SESSION['current_message_post'] = time();
	global $wait_post;
	$timeDiff_post = $_SESSION['current_message_post'] - $_SESSION['prev_message_post'];
	$floodInterval_post	= 45;
	$wait_post = $floodInterval_post - $timeDiff_post ;	
	if($timeDiff_post <= $floodInterval_post)
	return true;
	else 
	return false;
}
#######################################
# FUNCTIONS RELATE EPISODE
#######################################
function episode_show($total_episode,$film_id,$episode_id,$episode_name){
	global $mysql,$tb_prefix,$link_href,$web_link;
	$q = $mysql->query("SELECT episode_id, episode_name, episode_type FROM ".$tb_prefix."episode WHERE episode_film = ".$film_id." ORDER BY episode_id ASC");
	$film = $mysql->fetch_array($mysql->query("SELECT film_name, film_name_ascii, film_name_real FROM ".$tb_prefix."film WHERE film_id = '".$film_id."'"));
	     while ($r = $mysql->fetch_array($q)){
	  $episode_type = $r['episode_type'];
	  switch($episode_type){
	      case '1':
		        $sv1 .= "<a href=\"watch/".$r['episode_id']."/".replace($film['film_name_ascii'])."\"><font class=\"episode_bg_1\"><b>".$r['episode_name']."</b></font></a>&nbsp; ";
		  break;
	      case '2':
		        $sv2 .= "<a href=\"watch/".$r['episode_id']."/".replace($film['film_name_ascii'])."\"><font class=\"episode_bg_1\"><b>".$r['episode_name']."</b></font></a>&nbsp; ";
		  break;
	      case '3':
		        $sv3 .= "<a href=\"watch/".$r['episode_id']."/".replace($film['film_name_ascii'])."\"><font class=\"episode_bg_1\"><b>".$r['episode_name']."</b></font></a>&nbsp; ";
		  break;
		   case '4':
		        $sv4 .= "<a href=\"watch/".$r['episode_id']."/".replace($film['film_name_ascii'])."\"><font class=\"episode_bg_1\"><b>".$r['episode_name']."</b></font></a>&nbsp; ";
		  break;
	      case '5':
		        $sv5 .= "<a href=\"watch/".$r['episode_id']."/".replace($film['film_name_ascii'])."\"><font class=\"episode_bg_1\"><b>".$r['episode_name']."</b></font></a>&nbsp; ";
		  break;
		  case '6':
		        $sv6 .= "<a href=\"watch/".$r['episode_id']."/".replace($film['film_name_ascii'])."\"><font class=\"episode_bg_1\"><b>".$r['episode_name']."</b></font></a>&nbsp; ";
		  break;
	      case '7':
		        $sv7 .= "<a href=\"watch/".$r['episode_id']."/".replace($film['film_name_ascii'])."\"><font class=\"episode_bg_1\"><b>".$r['episode_name']."</b></font></a>&nbsp; ";
		  break;
		  case '8':
		        $sv8 .= "<a href=\"watch/".$r['episode_id']."/".replace($film['film_name_ascii'])."\"><font class=\"episode_bg_1\"><b>".$r['episode_name']."</b></font></a>&nbsp; ";
		  break;
		  case '9':
		        $sv9 .= "<a href=\"watch/".$r['episode_id']."/".replace($film['film_name_ascii'])."\"><font class=\"episode_bg_1\"><b>".$r['episode_name']."</b></font></a>&nbsp; ";
		  break;
	  }
		 }
$total_server .= "<div class=\"list_episodes content\">";
if($sv1) $total_server .= '<div class="listserver"><span class="name">Server VNHài 01:</span>'.$sv1.'</div>';
if($sv2) $total_server .= '<div class="listserver"><span class="name">Server VNHài 02:</span>'.$sv2.'</div>';
if($sv3) $total_server .= '<div class="listserver"><span class="name">Server VNHài 03:</span>'.$sv3.'</div>';
if($sv4) $total_server .= '<div class="listserver"><span class="name">Server Youtube:</span>'.$sv4.'</div>';
if($sv5) $total_server .= '<div class="listserver"><span class="name">Server VNHài 04:</span>'.$sv5.'</div>';
if($sv6) $total_server .= '<div class="listserver"><span class="name">Server USA:</span>'.$sv6.'</div>';
if($sv7) $total_server .= '<div class="listserver"><span class="name">Server Zing:</span>'.$sv7.'</div>';
if($sv8) $total_server .= '<div class="listserver"><span class="name">Server Yotube VIP:</span>'.$sv8.'</div>';
if($sv9) $total_server .= '<div class="listserver"><span class="name">Server VNHai.Com:</span>'.$sv9.'</div>';
$total_server .= "</div>";
$total_server = str_replace('<a href="watch/'.$episode_id.'/'.replace($film['film_name_ascii']).'"><font class="episode_bg_1"><b>'.$episode_name.'</b></font></a>','<font class="episode_bg_2">&nbsp; '.$episode_name.'&nbsp; </font>',$total_server);
	return $total_server;
}
?>