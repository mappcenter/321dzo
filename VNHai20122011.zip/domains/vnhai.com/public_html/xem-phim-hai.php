<?php 
define('IN_MEDIA',true); 
include('inc/_config.php'); 
include('inc/_functions.php'); 
$limit = $_GET['num'];
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<table style="width: 100%;" border="0" cellpadding="0" cellspacing="0"> 
<tbody>
<tr> 
 
</tr>
<tr> 
<?php
$type=$_GET['type'];
if ($type == 'new') {
	$where_sql = ""; $order_sql = "ORDER BY film_id";
	}
	elseif ($type == 'top') {
	$where_sql = "WHERE film_viewed_day > 0"; $order_sql = "ORDER BY film_viewed_day";
	}
	elseif ($type == 'rand') {
	$where_sql = ""; $order_sql = "ORDER BY RAND()";
	}
	elseif ($type == 'rate') {
	$where_sql = "WHERE film_rating_total >= 1"; $order_sql = "ORDER BY film_id";
	}
	elseif ($type == 'relate') {
	$where_sql = "WHERE film_cat = $cat_id"; $order_sql = "ORDER BY film_id";
	}
	elseif ($type == 'phimle') {
	$where_sql = "WHERE film_lb = 0"; $order_sql = "ORDER BY film_id";
	}
	elseif ($type == 'phimbo') {
	$where_sql = "WHERE film_lb = 1"; $order_sql = "ORDER BY film_id";
	}
	elseif ($type == 'dangchieurap') {
	$where_sql = "WHERE film_type = 2"; $order_sql = "ORDER BY film_id";
	}
	elseif ($type == 'sapchieurap') {
	$where_sql = "WHERE film_type = 3"; $order_sql = "ORDER BY film_id";
	}	
	elseif ($type == 'decu') {
	$where_sql = "WHERE film_type = 1"; $order_sql = "ORDER BY film_id";
	}
	else {
		$where_sql = ""; $order_sql = "ORDER BY film_id";
	}
$url_site='http://vnhai.com/info/';
if ($limit == "" ) {$limit = 10;} 
//$where_sql = ""; $order_sql = "ORDER BY film_id";
//	$where_sql = "WHERE film_viewed_day > 0"; 
	//$order_sql = "ORDER BY film_viewed_day";
	$query = $mysql->query("SELECT * FROM ".$tb_prefix."film $where_sql $order_sql DESC LIMIT ".$limit);
	$total = get_total("film","film_id","$where_sql $order_sql");
	$i = 1;
	while ($rs = $mysql->fetch_array($query)) {
		$flim_name = $rs['film_name'];
		$flim_name_acsii = replace(trim($rs['film_name_ascii']));
		$film_name_real=check_data($r['film_name_real']);
		$film_name_cut=substr($flim_name,0,20)."...";
		$film_id = $rs['film_id'];
	    $film_img = check_img($rs['film_img']);
	    $film_year = check_data($rs['film_year']);
	    $film_time = check_data($rs['film_time']);
	    $film_director = check_data($rs['film_director']);
	    $film_actor = check_data($rs['film_actor']);
	    $film_cat = check_data(get_data('cat_name','cat','cat_id',$rs['film_cat']));
		$film_country = check_data(get_data('country_name','country','country_id',$r['film_country']));
		$i++; 
		$tr=(fmod($i,2)==0)?'</tr><tr>':''; 

?> 

<!-- BEGIN film_menu -->
<!-- #BEGIN rand_film.row -->
	<td>
	<!--		<marquee height="145px" scrolldelay="1" scrollamount="1" direction="up" onmouseout="this.start();" onmouseover="this.stop();">-->
				<table>
					<tbody>
					<tr>
					<td rowspan="2" style=""><a href="<?=$url_site.$film_id.'/'.$flim_name_acsii?>" target="_blank"><img src="<?=$film_img?>" title="<?=$flim_name?>" alt="<?=$flim_name?>" width="100" border="0" height="130"></a>
						<center><div class="box_top_film_main"><font color="Yellow"><p class="img"><a href="<?=$url_site.$film_id.'/'.$flim_name_acsii?>" title="<?=$flim_name?>"><?=$film_name_cut?></a></p></font></div></center>
				</td>
					</tr>

					</tbody>
				</table>

	</td> 

	<!-- #END rand_film.row -->
<!-- END film_menu -->
<?php 
 } 
?> 


</tr>
</tbody></table>

<style>
body{
	font-family:Arial;
	font-size:10px;
    background-image:url();
    text-align:center;
}
.box_top_film_main{
	font-family:Arial;
	font-size:11px;
	float:center;
	text-align:center;

}
img { border:none;	margin: 0;padding: 0;}
#singer a {text-decoration:none; color:#09F; font-size: 12px;}
#singer a:hover {text-decoration:none; color:#9AC02F;}
a{text-decoration:none; color:#454545; font-size: 12px;}
a:hover{text-decoration:underline;}
.menu a{
font: normal 12px Arial;
color: #FFBC79;
display: block;
padding: 5px 0;
line-height: 17px;
padding-left: 8px; /*link text is indented 8px*/
text-decoration: none;
text-align:center;
}

.menu a:visited{
color: #FFBC79;
}

.menu a:hover{ /*hover state CSS*/
background-color: #000;
color: #FFBC79;}
.menu
{
	background-color: #000;
	background-repeat:repeat-x;
	float:center;
	padding-top:8px;
	text-align:center;
}
</style>
