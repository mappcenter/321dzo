package com.t3h.project;


import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import org.apache.http.util.ByteArrayBuffer;
import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.widget.TabHost;

public class MyMovieActivity extends TabActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Resources res = getResources(); // Resource object to get Drawables
        TabHost tabHost = getTabHost();  // The activity TabHost
        TabHost.TabSpec spec;  // Resusable TabSpec for each tab
        Intent intent;  // Reusable Intent for each tab

        // Create an Intent to launch an Activity for the tab (to be reused)
        intent = new Intent().setClass(this, NewMovie.class);

        // Initialize a TabSpec for each tab and add it to the TabHost
        spec = tabHost.newTabSpec("new").setIndicator("New",
                          res.getDrawable(R.drawable.ic_tab_new))
                      .setContent(intent);
        tabHost.addTab(spec);

        // Do the same for the other tabs
        intent = new Intent().setClass(this, HotMovie.class);
        spec = tabHost.newTabSpec("hot").setIndicator("Hot",
                          res.getDrawable(R.drawable.ic_tab_hot))
                      .setContent(intent);
        tabHost.addTab(spec);

        intent = new Intent().setClass(this, InfoMovie.class);
        spec = tabHost.newTabSpec("info").setIndicator("Info",
                          res.getDrawable(R.drawable.ic_tab_info))
                      .setContent(intent);
        tabHost.addTab(spec);

        intent = new Intent().setClass(this, MemberMovie.class);
        spec = tabHost.newTabSpec("member").setIndicator("Member",
                          res.getDrawable(R.drawable.ic_tab_member))
                      .setContent(intent);
        tabHost.addTab(spec);
        
        tabHost.setCurrentTab(0);
        
        String myDownloadNew = getString(R.string.link_new_movie);
        String myDownloadFileNameNew = "new_film.xml";
        DownloadFromUrl(myDownloadNew,myDownloadFileNameNew);
        
        String myDownloadHot = getString(R.string.link_hot_movie);
        String myDownloadFileNameHot = "hot_film.xml";
        DownloadFromUrl(myDownloadHot,myDownloadFileNameHot);

    }
    
    public void DownloadFromUrl(String DownloadUrl, String fileName) {

        try {
                File root = android.os.Environment.getExternalStorageDirectory();               

                File dir = new File (root.getAbsolutePath() + "/xmls");
                if(dir.exists()==false) {
                     dir.mkdirs();
                }

                URL url = new URL(DownloadUrl); //you can write here any link
                File file = new File(dir, fileName);

                long startTime = System.currentTimeMillis();
                Log.d("DownloadManager", "download begining");
                Log.d("DownloadManager", "download url:" + url);
                Log.d("DownloadManager", "downloaded file name:" + fileName);

                /* Open a connection to that URL. */
                URLConnection ucon = url.openConnection();

                /*
                 * Define InputStreams to read from the URLConnection.
                 */
                InputStream is = ucon.getInputStream();
                BufferedInputStream bis = new BufferedInputStream(is);

                /*
                 * Read bytes to the Buffer until there is nothing more to read(-1).
                 */
                ByteArrayBuffer baf = new ByteArrayBuffer(5000);
                int current = 0;
                while ((current = bis.read()) != -1) {
                   baf.append((byte) current);
                }


                /* Convert the Bytes read to a String. */
                FileOutputStream fos = new FileOutputStream(file);
                fos.write(baf.toByteArray());
                fos.flush();
                fos.close();
                Log.d("DownloadManager", "download ready in" + ((System.currentTimeMillis() - startTime) / 1000) + " sec");

        } catch (IOException e) {
            Log.d("DownloadManager", "Error: " + e);
        }

     }
}