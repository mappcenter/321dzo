<?php
if (!defined('IN_MEDIA')) die("Hacking attempt");
function cut_str($str_cut,$str_c,$val)
{	
	$url=split($str_cut,$str_c);
	$urlv=$url[$val];
	return $urlv;
}
function get_link_total($url,$type) {
	//http://movie.zing.vn/Movie/a34682bc.aspx
	global $web_link,$link_seo,$episode_id;
	$link=$url;
	$mylink='http://getlink.thienduongviet.org/';
	$t="";
	if (preg_match("#thienduongviet.org/getlink/(.*?)#", $url)){
			$link=str_replace('http://thienduongviet.org/getlink',$mylink,$url);
			$url=$link;
		}
	elseif (preg_match('#veoh.com/browse/videos/category/([^/]+)/watch/([^/]+)#', $url, $id_sr)){
		$id = $id_sr[2];
		$link=$mylink.'/veoh/'.$id.'.flv';
		$url="http://www.phim88.com/online/xxxxxx?plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf,http://thienduongviet.org/movie/linkPlugin.swf&plugin.thienduongviet=true&plugin.chia_se_link=$link_seo&plugin.tdv_id=movie/xml/$episode_id&skin=http://thienduongviet.org/movie/blue.swf";
    }
	elseif (preg_match('#www.veoh.com\/videodetails2\.swf\?permalinkId=(.*?)#s', $url) || preg_match('#www.veoh.com\/veohplayer\.swf\?permalinkId=(.*?)#s', $url)){
		$id = cut_str('=',$url,1);
		$id = cut_str('&',$id,0);
		$link=$mylink.'/veoh/'.$id.'.flv';
		$url="http://www.phim88.com/online/xxxxxx?plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf,http://thienduongviet.org/movie/linkPlugin.swf&plugin.thienduongviet=true&plugin.chia_se_link=$link_seo&plugin.tdv_id=movie/xml/$episode_id&skin=http://thienduongviet.org/movie/blue.swf";
    }
	
    elseif (preg_match('#veoh.com/(.*?)#s', $url, $id_sr)){
		$linkvideo=explode('/', $url);
		$num=count($linkvideo);
		$id=$linkvideo[$num-1];
		$link=$mylink.'/veoh/'.$id.'.flv';
		$url="http://www.phim88.com/online/xxxxxx?plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf,http://thienduongviet.org/movie/linkPlugin.swf&plugin.thienduongviet=true&plugin.chia_se_link=$link_seo&plugin.tdv_id=movie/xml/$episode_id&skin=http://thienduongviet.org/movie/blue.swf";
    }
    elseif (preg_match("#blog.com.vn/Video/([^/_]+)_([^/.]+).html#",$url,$id_sr)) {
		$id = $id_sr[2];
		$url = "http://blog.com.vn/embed/f/f/".$id;
		$link=$mylink.'/blogvn/'.$id.'.flv';
		$t="f";
    }
	elseif(preg_match('#http:\/\/clip.vn\/watch\/([^/,]+),([^/]+)#', $url, $id_sr)) {
		$id = $id_sr[2];
		$url = 'http://clip.vn/w/'.$id.',a';
		$t="f";
	}
    elseif (preg_match("#dailymotion.com/(.*?)#s",$url,$id_sr)) {
		$linkvideo=explode('/', $url);
		$num=count($linkvideo);
		$link=$linkvideo[$num-1];
		$id=explode('_', $link);
		$id=explode('&', $id[0]);
		$link=$mylink.'/daily/'.$id[0].'.flv';
		$url='http://www.dailymotion.com/swf/'.$id[0];
		//$url=$web_link.'/'.'player.swf?file='.$link.'&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link='.$link_seo;
		
    }
    elseif (preg_match("#youtube.com/watch([^/]+)#",$url,$id_sr)) {
		$id = cut_str('=',$url,1);
		/*$url = "http://www.youtube.com/watch?v=".$id;*/
		$link=$mylink.'/youtube/'.$id.'.flv';
		$link=$mylink.'/youtube/'.$id.'.xml';
		$url="http://www.youtube.com/v/".$id;
		$url=$web_link.'/'.'player.swf?file=http://www.youtube.com/watch%3Fv%3D'.$id;

    }
	elseif (preg_match("#youtube.com/view_play_list([^/]+)#",$url,$id_sr)) {

		$id = cut_str('=',$url,1);

		$link='http://thienduongviet.org/getlink/youtube/playlist'.$id.'.html';

		$link2='http://thienduongviet.org/getlink/youtube/playlist'.$id.'.xml';

		$url=$web_link.'/'.'player.swf?autostart=true&playlist=over&file='.$link2;

    }
	/* Cai Dang Xai
	elseif (preg_match("#youtube.com/v/([^/]+)#",$url,$id_sr)) {
		$id = cut_str('/',$url,4);
		$link=$mylink.'/youtube/'.$id.'.flv';
		$link=$mylink.'/youtube/'.$id.'.xml';
		$url="http://www.youtube.com/v/".$id;
		$url=$web_link.'/'.'player.swf?file=http://www.youtube.com/watch%3Fv%3D'.$id;
		
    } */
	elseif (preg_match("#youtube.com/view_play_list([^/]+)#",$url,$id_sr)) {
		$id = cut_str('=',$url,1);
		$link=$mylink.'/youtube/playlist/'.$id.'.html';
		$link2=$mylink.'/youtube/playlist/'.$id.'.xml';
		$url=$web_link.'/'.'player.swf?file='.$mylink.'/youtube/playlist/'.$id.'.xml&playlist=over';
    }
	/*elseif (preg_match("#video.google.com/#",$url,$id_sr)) {
		$link=str_replace('docId=','docid',$url);
		$link .='&';
		$id = cut_str('docid=',$link,1);
		$id = cut_str('&',$id,0);
		$link=$mylink.'/google/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link.'&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link='.$link_seo;
		
    }*/
	elseif (preg_match("#sevenload.com/videos/([^/-]+)-([^/]+)#",$url,$id_sr)) {
		$linkvideo=explode('/', $link);
		$num=count($linkvideo);
		$link=$linkvideo[$num-1];
		$id=explode('-', $link);
		$link=$mylink.'/sevenload/'.$id[0].'.flv';
		$url=$web_link.'/player.swf?file='.$link;
		
    }
	else if (preg_match("#video.zing.vn/video/(.*?)#s", $url)){
		$url="$web_link/player2.swf?plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf,http://thienduongviet.org/movie/linkPlugin.swf&plugin.thienduongviet=true&plugin.chia_se_link=$link_seo&plugin.tdv_id=movie/xml/$episode_id&skin=http://thienduongviet.org/movie/blue.swf";		
	}
	else if (preg_match("#http://movie.zing.vn/Movie/xem-online/(.*?)#s", $url)){
		$link=str_replace(array('http://movie.zing.vn/Movie/xem-online/','.html'),array($mylink.'/zingm/','.wpl'),$url);
		$url=$link;
	}
	else if (preg_match("#video.yume.vn/playlist/(.*?)#s", $url)){
		$link=str_replace('http://video.yume.vn/',$mylink.'/timnhanh/',$url);
		$link=trim($link);
		$link2 = cut_str('&',$link,0).'.xml';
		$link = cut_str('&',$link,0).'.flv';
		if (substr_count($_SERVER['HTTP_USER_AGENT'],'Firefox')!=0){
			$url="$web_link/player.swf?file=$link&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link=$link_seo";
		}else $url="http://static.yume.vn/yumevideo/20100201/flash_player/player_homepage.swf?xmlPath=$url&mAuto=true&colorAux=0xe0e0e0&colorMain=0x3d78f6&colorBorder=0x5a5a5a";
	}
	else if ((preg_match("#video.timnhanh.com(.*?)#s", $url)) || (preg_match("#video.yume.vn(.*?)#s", $url))){
		$link=str_replace(array('http://video.timnhanh.com/','http://video.yume.vn/'),$mylink.'/timnhanh/',$url);
		$link2=str_replace('.html','.xml',$link);
		$link=str_replace('.html','.flv',$link);
		if (substr_count($_SERVER['HTTP_USER_AGENT'],'Firefox')!=0){
		$url="$web_link/player.swf?file=$link&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link=$link_seo";
		}else $url="http://static.yume.vn/yumevideo/20100201/flash_player/player_homepage.swf?xmlPath=$link2&mAuto=true&colorAux=0xe0e0e0&colorMain=0x3d78f6&colorBorder=0x5a5a5a";
	}
	else if (preg_match("#badongo.com/vid/(.*?)#s", $url,$id_sr)){
		$id=cut_str('/',$url,4);
		$link2=$mylink.'/badongo/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link2.'&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link='.$link_seo;;
		
	}
	else if (preg_match("#megavideo.com/\?v=(.*?)#s", $url,$id_sr)){
		$id=cut_str('=',$url,1);
		$link=$mylink.'/megavideo/'.$id.'.flv';
		//$url=$web_link.'/'.'player.swf?file='.$link.'&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link='.$link_seo;
		//$url='http://wwwstatic.megavideo.com/mv_player.swf?v='.$id;
		$url='http://www.megavideo.com/ep_gr.swf?v=UYPTH58N?v='.$id;
		
		//$url='http://www.chia-anime.com/wp-content/themes/player2.swf?config=http://www.chia-anime.com/mvplayer.php%3Ffile='.$id.'&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link='.$link_seo&skin='.$web_link.'/blue.swf';
	}
	else if (preg_match("#^http://www.metacafe.com/watch/(.*?)#s", $url)){
		$id = cut_str('/',$url,4);
		$link=$mylink.'/metacafe/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link.'&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link='.$link_seo;
	}
	else if (preg_match("#^http://timvui.vn/video/(.*?)#s", $url)){
		$id = cut_str('view/',$url,1);
		$id = cut_str('\.',$id,0);
		$link=$mylink.'/timvui/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link.'&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link='.$link_seo;
		$url='http://timvui.vn/player/vPlayer.swf?f=http://timvui.vn/player/vConfig.php?videoid='.$id;
	}
	else if (preg_match("#nhaccuatui.com(.*?)#s", $url)){
			$id = cut_str('=',$url,1);
			$link=$mylink.'/nct/'.$id.'.flv';
			$url='http://www.nhaccuatui.com/m2/'.$id;
			//$url=$web_link.'/'.'player.swf?file='.$link.'&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link='.$link_seo;
	}
	else if (preg_match("#video.baamboo.com(.*?)#s", $url)){
			$t = cut_str('/',$url,4);
			$id =cut_str('/',$url,6);
			$link=$mylink.'/baamboo/'.$id.'_'.$t.'.flv';
			$url=$web_link.'/'.'player.swf?file='.$link.'&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link='.$link_seo;
	}
	else if (preg_match("#video.baamboo.com(.*?)#s", $url)){
			$t = cut_str('/',$url,4);
			$id =cut_str('/',$url,6);
			$link=$mylink.'/baamboo/'.$id.'_'.$t.'.flv';
			$url=$web_link.'/'.'player.swf?file='.$link.'&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link='.$link_seo;
	}
	else if (preg_match("#www.sendspace.com/file/(.*?)#s", $url)){
		$id = cut_str('/',$link,4);
		$link2=$mylink.'/sendspace/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link2.'&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link='.$link_seo;
	}
	elseif (preg_match('#2shared.com/file/([^/]+)#', $url, $id)){
		$link2=str_replace(array('http://2shared.com/file/','http://www.2shared.com/file/'),$mylink.'/2shared/',$link);
		$link2=str_replace('.html','.flv',$link2);
		$url="http://www.phim88.com/online/xxxxxx?file=$link2&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link='.$link_seo&skin=http://thienduongviet.org/movie/blue.swf";
	}
	else if (preg_match("#4shared.com/video/(.*?)#s", $link)){
		$id = cut_str('/',$link,4);
		$link2=$myurl.'/4shared/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link2.'&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link='.$link_seo;
	}
	else if (preg_match("#4shared.com/audio/(.*?)#s", $link)){
		$id = cut_str('/',$link,4);
		$link2=$myurl.'/4shared/'.$id.'.mp3';
		$url=$web_link.'/'.'player.swf?file='.$link2.'&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link='.$link_seo;
	}
	else if (preg_match("#megashare.vn(.*?)#s", $link)){
		$link2=str_replace('http://megashare.vn/dl.php/',$myurl.'/megashare/',$link);
		$link2=$link2.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link2.'&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link='.$link_seo;
	}
	else if (preg_match("#^http:\/\/movies.tialia.com/(.*?)#s", $link)){
		$id = cut_str('_',$link,1);
		$id=str_replace('.html','.flv',$id);
		$link=$myurl.'/tialiamovie/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link.'&plugins=http://static.hosting.vcmedia.vn/players/plugins/sharePlugin.swf&plugin.chia_se_link='.$link_seo;
	}
	if (($t=="") && (substr_count($url,$web_link.'/player.swf') != 0)) 
		$url=$url.'&skin=skin.swf&logo='.$web_link.'/logo.png';
	if ($type==0) $trave=$url;
	elseif ($type==1) $trave=$link;
return $trave;
}

?>