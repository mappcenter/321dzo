<?php 

//------------Code by: Pham Thanh Liem
//------------Shared at: 321Dzo.Com
//------------Vui long ko sua 3 dong chu thich nay khi su dung code duoc share, Thanks !
//-----------------------------------------------------------------------------------------------

$db_host	= 'localhost';
$db_name	= 'vnhaicom_db';
$db_user	= 'vnhaicom_admin';
$db_pass	= 'E7k6T9nt';
$tb_prefix	= 'app_';

$basic_link	= 'http://yamato.vn/KhachHang/lien-ket.php';
$basic_title	= 'Free Auto Backlink Exchange Service';
$basic_img	= $basic_link.'images/backlinks.png';

$con = mysql_connect($db_host,$db_user,$db_pass);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

// some code
mysql_select_db($db_name, $con);

echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
?> 
<?php
		$Page = ""; 		
		$Page = $_GET["pg"];

		switch ($Page){
		case "TOP" :		
?>
<NewFilmList>
<?php
	$result = mysql_query("SELECT * FROM app_phim WHERE film_type = 1 ORDER BY film_show DESC LIMIT 20");
	$STT=1;
	while($row = mysql_fetch_array($result)){
?>
	<Film>
		<FilmTitle><?php echo$row['film_title']; ?></FilmTitle>
		<FilmPicture><?php echo$row['film_image']; ?></FilmPicture>
		<FilmTime>15</FilmTime>
		<FilmCount><?php echo$row['film_show']; ?></FilmCount>
		<FilmURL><?php echo$row['film_link']; ?></FilmURL>
	</Film>
<?php
	$STT++;
	}
?>
</NewFilmList>

<?php		break;
		default: 
?>
<NewFilmList>
<?php
	$result = mysql_query("SELECT * FROM app_phim WHERE film_type = 1 ORDER BY film_ID DESC LIMIT 20");
	$STT=1;
	while($row = mysql_fetch_array($result)){
?>
	<Film>
		<FilmTitle><?php echo$row['film_title']; ?></FilmTitle>
		<FilmPicture><?php echo$row['film_image']; ?></FilmPicture>
		<FilmTime>15 Phút</FilmTime>
		<FilmCount><?php echo$row['film_show']; ?></FilmCount>
		<FilmURL><?php echo$row['film_link']; ?></FilmURL>
	</Film>
<?php
	$STT++;
	}
?>
</NewFilmList>
<?php
}
?>