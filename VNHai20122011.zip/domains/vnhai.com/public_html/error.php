<?php
if (!defined('IN_MEDIA')) die("Hack");
	$htm = $temp->get_htm('error');
	$main= $temp->replace_value($htm,
		array(
				'ERROR'			=> "Phần này chưa có dữ liệu",
		)
	);

?>