<?php
if (!defined('IN_MEDIA_ADMIN')) die("Hacking attempt");
//Add  Multi Episode of Film - Code by nguyentruongxuanl_dzy@yahoo.com
if ((!$_POST['ok']) AND (!$_POST['submit']))  {
?>
<form method="post">
<table class=border cellpadding=2 cellspacing=0 width=30%>
<tr><td class=title align=center colspan=2>ADD FILM</td></tr>
<tr>
	<td class=fr align=center><input name="episode_begin" size="15" value="EPISODE BEGIN" onclick="this.select()" style="text-align:center;background:violet;font-weight: bold;"></td>
</tr>
<tr>
	<td class=fr align=center><input name="episode_end" size="15" value="EPISODE END" onclick="this.select()" style="text-align:center;background:yellow;font-weight: bold;"></td>
</tr>
<tr><td class=fr colspan=2><b>Chú ý:</b> <font color=red>Đăng 1 tập phim thì hãy điều tên tập đó vào ô màu vàng nhá ^^</font></td></tr>
<tr><td class=fr align=center colspan=2><input type="submit" name="ok" class="submit" value="SUBMIT"></td></tr>
</table>
</form>
<?
}
else
{
$begin = $_POST['episode_begin'];
$end = $_POST['episode_end'];
////BEGIN CHECK EPISODE
if(!is_numeric($begin) && !is_numeric($end)){
$episode_begin = 1;
$episode_end = 10;
}elseif(!is_numeric($begin)){
$episode_begin = $episode_end = $end;
}else{
$episode_begin = $begin; $episode_end = $end;
}
////END CHECK EPISODE
if (!$_POST['submit']) {
?>
<script>
var total = <?=$episode_end?>;
function check_local(id){
    for(i=1;i<=total;i++)
           document.getElementById("local_url["+i+"]").value=id;
}
</script> 
<form enctype="multipart/form-data" method=post>
<table class=border cellpadding=2 cellspacing=0 width=95%>
<tr><td colspan=2 class=title align=center>MULTI ADD EPISODES</td></tr>

<tr>
	<td class=fr width=30%><b>CHOOSED FILM</b></td>
	<td class=fr_2><?=acp_film()?></td>
</tr>

<tr>
	<td class=fr width="30%">
		<b>QUICK ADD FILM</b>
		<br>If database ised havent Web is gently self-made</td>
	<td class=fr_2>
	<table cellpadding=2 cellspacing=0 width=100%>	
	<tr>
	<td width="40%" align="right"><b>NAME</b></td>
	<td><input name="new_film" size="50"></td>
    </tr>
    <tr>
	<td width="40%" align="right"><b>NAME REAL</b></td>
	<td><input name="name_real" size="50"></td>
    </tr>
	<tr>
	<td width="40%" align="right"><b>IMG</b></td>
	<td class=fr_2><input name="upload_img" size="37" type="file"><BR /><BR />
	    <input name="url_img" size="49"></td>
    </tr>
	<tr>
	<td width="40%" align="right"><b>DIRECTOR</b></td>
	<td><input name="director" size="50"></td>
    </tr>
	<tr>
	<td width="40%" align="right"><b>ACTOR</b></td>
	<td><input name="actor" size="50"></td>
    </tr>
	<tr>
	<td width="40%" align="right"><b>PRODUCER</b></td>
	<td><input name="area" size="50"></td>
    </tr>
    <tr>
	<td width="40%" align="right"><b>TIME</b></td>
	<td><input name="time" size="50"></td>
    </tr>
	<tr>
	<td width="40%" align="right"><b>ISSUE DAY</b></td>
	<td><input name="year" size="50"></td>
    </tr>
	<tr>
	<td width="40%" align="right"><b>CATEGORY</b></td>
	<td><?=acp_cat()?></td>
    </tr>
	<tr>
	<td width="40%" align="right"><b>COUNTRY</b></td>
	<td><?=acp_country()?></td>
    </tr>
	<tr>
	<td colspan="2" align="center" style="padding-top:15px;"><textarea name="info" id="info" cols="100" rows="15"></textarea>
    <script language="JavaScript">generate_wysiwyg('info');</script></td>
    </tr>
	</table>
	</td>
</tr>

<tr>
    <td class=fr width=30%><b>LOCAL SERVER</b></td>
    <td class=fr_2><?=acp_local(0,'main')?> 
</td>
<?php
for ($i=$episode_begin;$i<=$episode_end;$i++) {
?>
<tr>
<td class=fr width=30%><b>EPISODE NUMBER <input onclick="this.select()" type="text" name="name[<?=$i?>]" value="<?=$i?>" size=2 style="text-align:center"></b></td><td class=fr_2><input type="text" name="url[<?=$i?>]" size="50"> <?=acp_local(0,$i)?></td>
</tr>
<?php
}
?>
<tr><td class=fr colspan=2 align=center><input type="hidden" name="episode_begin" value="<?=$episode_begin?>">
<tr><td class=fr colspan=2 align=center><input type="hidden" name="episode_end" value="<?=$episode_end?>">
<input type="hidden" name="ok" value="SUBMIT"><input type="submit" name="submit" class="submit" value="SUBMIT"></td></tr>
</table>
</form>
<?php
}
else {	
	if ($new_film) {
	            if(move_uploaded_file ($_FILES['upload_img']['tmp_name'],'../'.$img_film_folder."/".$_FILES['upload_img']['name']))
				$new_film_img = $img_film_folder."/".$_FILES['upload_img']['name'];
				else $new_film_img = $_POST['url_img'];
				$film = acp_quick_add_film($new_film,$name_real,$new_film_img,$actor,$year,$time,$area,$director,$cat,$info,$country);
	}	
	$t_film = $film;
    for ($i=$episode_begin;$i<=$episode_end;$i++){
		$t_url = $_POST['url'][$i];
		$t_name = $_POST['name'][$i];
		$t_type = acp_type($t_url);
		$t_local = $_POST['local_url'][$i];
		if ($t_url && $t_name) {
		$mysql->query("INSERT INTO ".$tb_prefix."episode (episode_film,episode_url,episode_type,episode_name,episode_local) VALUES ('".$t_film."','".$t_url."','".$t_type."','".$t_name."','".$t_local."')");
		}
	}
	echo "Đã thêm xong <meta http-equiv='refresh' content='0;url=index.php?act=episode&mode=multi_add'>";
  }
}
?>