<?php
if (!defined('IN_MEDIA_ADMIN')) die("Hacking attempt");
$menu_arr = array(
	'cat'	=>	array(
		'CATEGORY',
		array(
			'edit'	=>	array('DANH S&#193;CH TH&#7874; LO&#7840;I','act=cat&mode=edit'),
			'add'	=>	array('TH&#202;M TH&#7874; LO&#7840;I','act=cat&mode=add'),
		),
	),
	'film'	=>	array(
		'FILM',
		array(
			'add_episode'	=>	array('TH&#202;M PHIM','act=episode&mode=multi_add'),
			'edit'	=>	array('DANH S&#193;CH PHIM','act=film&mode=edit'),
			'edit_broken'	=>	array('PHIM B&#7882; L&#7894;I','act=film&mode=edit&show_broken=1'),
			'edit_phimle'	=>	array('PHIM LẺ','act=film&mode=edit&show_film_lb=0'),
			'edit_phimbo'	=>	array('PHIM BỘ','act=film&mode=edit&show_film_lb=1'),
			'edit_dangchieurap'	=>	array('PHIM ĐANG CHIẾU RẠP','act=film&mode=edit&show_film_type=2'),
			'edit_sapchieurap'	=>	array('PHIM SẮP CHIẾU RẠP','act=film&mode=edit&show_film_type=3'),
			'edit_decu'	=>	array('PHIM ĐỀ CỬ','act=film&mode=edit&show_film_type=1'),
			'add_request'	=>	array('Y&#202;U C&#7846;U PHIM','act=request&mode=edit'),
		),
	),
	'country'	=>	array(
		'COUNTRY',
		array(
			'edit'	=>	array('DANH S&#193;CH QU&#7888;C GIA','act=country&mode=edit'),
			'add'	=>	array('TH&#202;M QU&#7888;C GIA','act=country&mode=add'),
		),
	),
	'news'	=>	array(
		'NEWS',
		array(
			'edit'	=>	array('DANH S&#193;CH TIN T&#7912;C','act=news&mode=edit'),
			'add'	=>	array('TH&#202;M TIN T&#7912;C','act=news&mode=add'),
		),
	),
	'user'	=>	array(
		'USER',
		array(
			'edit'	=>	array('DANH S&#193;CH TH&#192;NH VI&#202;N','act=user&mode=edit'),
			'add'	=>	array('TH&#202;M TH&#192;NH VI&#202;N','act=user&mode=add'),
		),
	),
	'link'	=>	array(
		'ADS',
		array(
			'edit'	=>	array('DANH S&#193;CH QU&#7842;NG C&#193;O','act=ads&mode=edit'),
			'add'	=>	array('TH&#202;M QU&#7842;NG C&#193;O','act=ads&mode=add'),
		),
	),
	'skin'	=>	array(
		'SKIN',
		array(
			'edit'	=>	array('DANH S&#193;CH SKIN','act=skin&mode=edit'),
			'add'	=>	array('TH&#202;M SKIN','act=skin&mode=add'),
		),
	),
	'config'	=>	array(
		'WEBSITE',
		array(
			'permission'	=>	array('GI&#7898;I H&#7840;N QUY&#7872;N TH&#192;NH VI&#202;N','act=permission'),
			'config'	=>	array('C&#7844;U H&#204;NH','act=config'),
			'comment'	=>	array('DANH S&#193;CH C&#7842;M NH&#7852;N','act=comment&mode=edit'),
			'local'	=>	array('LOCAL SERVER','act=local'),
		),
	)
);
if ($level == 2) {

	unset($menu_arr['config']);
	foreach ($menu_arr as $key => $v) {
		if (!$mod_permission['add_'.$key]) unset($menu_arr[$key][1]['add']);
		if (!$mod_permission['edit_'.$key]) unset($menu_arr[$key][1]['edit']);
		if ($key == 'film' && !$mod_permission['add_'.$key]) unset($menu_arr[$key][1]['add_episode']);
		if ($key == 'film' && !$mod_permission['add_'.$key]) unset($menu_arr[$key][1]['add_request']);
		if ($key == 'film' && !$mod_permission['edit_'.$key]) unset($menu_arr[$key][1]['edit_broken']);
		if ($key == 'film' && !$mod_permission['add_'.$key]) unset($menu_arr[$key][1]['edit_trailer']);
		if ($key == 'episode' && !$mod_permission['add_'.$key]) unset($menu_arr[$key][1]['add_multi']);
		if ($key == 'trailer' && !$mod_permission['edit_'.$key]) unset($menu_arr[$key][1]['edit_broken']);
		if (!$menu_arr[$key][1]) unset($menu_arr[$key]);
	}
}
echo "<div><a href='index.php?act=main'><b>MAIN</b></a> || <a href='logout.php'><b>LOGOUT</b></a></div>";
foreach ($menu_arr as $key => $arr) {
	echo "<table cellpadding=2 cellspacing=0 width=100% class=border style='margin-bottom:5'>";
	echo "<tr><td class=title><b>".$arr[0]."</b></td></tr>";
	foreach ($arr[1] as $m_key => $m_val) {
		echo "<tr><td>+ <a href=\"?".$m_val[1]."\">".$m_val[0]."</a></td></tr>";
	}
	echo "</table>";
}
echo "<div class=footer><a href=\"http://vnhai.com\" target=\"_blank\"><b>VNHài.Com</b></a></div>";
?>