<?php
define('IN_MEDIA',true);
include('inc/_config.php');
include('inc/_grab.php');
$id=$_GET['id'];
$type=$_GET['type'];
$xml="";
$q = $mysql->query("SELECT * FROM ".$tb_prefix."episode WHERE episode_id = $id ");
if ($type=="xml"){
	$rs = $mysql->fetch_array($q); 
	if($rs['episode_local']){
		$url = get_data('local_link','local','local_id',$rs['episode_local']).$rs['episode_url'];
		$xml .="<flv>$url</flv><youtube></youtube><nhaccuatui></nhaccuatui><mp3></mp3><zingvideo></zingvideo><veoh></veoh>";
	}else $url=$rs['episode_url'];
	
	if($rs['episode_type'] == 2 || $rs['episode_type'] == 3) 
		$xml .="<flv>http://thienduongviet.org/no.flv</flv><youtube></youtube><nhaccuatui></nhaccuatui><mp3></mp3><zingvideo></zingvideo><veoh></veoh>";
	elseif($rs['episode_type'] == 4) 
		$xml .="<flv></flv><youtube>$url</youtube><nhaccuatui></nhaccuatui><mp3></mp3><zingvideo></zingvideo><veoh></veoh>";
	elseif($rs['episode_type'] == 5)
		$xml .="<flv>$url</flv><youtube></youtube><nhaccuatui></nhaccuatui><mp3></mp3><zingvideo></zingvideo><veoh></veoh>";
	elseif($rs['episode_type'] == 13) {
			if (preg_match('#veoh.com/browse/videos/category/([^/]+)/watch/([^/]+)#', $url, $id_sr)){
				$id = $id_sr[2];
				$url='http://www.veoh.com/rest/v2/execute.xml?apiKey=5697781E-1C60-663B-FFD8-9B49D2B56D36&method=veoh.video.findByPermalink&permalink='.$id;
			}
			elseif (preg_match('#www.veoh.com\/videodetails2\.swf\?permalinkId=(.*?)#s', $url) || preg_match('#www.veoh.com\/veohplayer\.swf\?permalinkId=(.*?)#s', $url)){
			$id = cut_str('=',$url,1);
			$id = cut_str('&',$id,0);
			$url='http://www.veoh.com/rest/v2/execute.xml?apiKey=5697781E-1C60-663B-FFD8-9B49D2B56D36&method=veoh.video.findByPermalink&permalink='.$id;
		}
		elseif (preg_match('#veoh.com/(.*?)#s', $url, $id_sr)){
			$linkvideo=explode('/', $url);
			$num=count($linkvideo);
			$id=$linkvideo[$num-1];
			$url='http://www.veoh.com/rest/v2/execute.xml?apiKey=5697781E-1C60-663B-FFD8-9B49D2B56D36&method=veoh.video.findByPermalink&permalink='.$id;
		}
		$xml .="<veoh>$url</veoh><youtube></youtube><nhaccuatui></nhaccuatui><mp3></mp3><zingvideo></zingvideo><flv></flv>";
	}elseif($rs['episode_type'] == 14) 
		$xml .="<zingvideo>$url</zingvideo><youtube></youtube><nhaccuatui></nhaccuatui><mp3></mp3><veoh></veoh><flv></flv>";
	elseif($rs['episode_type'] == 21) 
		$xml .="<nhaccuatui>$url</nhaccuatui><youtube></youtube><mp3></mp3><zingvideo></zingvideo><veoh></veoh><flv></flv>";
	else $url = get_link_total($url,0);
	header("Content-Type: application/xml; charset=utf-8");
		echo '<?xml version="1.0" encoding="utf-8"?><thienduongviet version="1" xmlns="http://xspf.org/ns/0/"><listvideo>'.$xml.'</listvideo></thienduongviet>';
}
else{
	$rs = $mysql->fetch_array($q); 
	$episode_id=$id;
	if($rs['episode_local']) $url = get_data('local_link','local','local_id',$rs['episode_local']).$rs['episode_url'];
	else $url=$rs['episode_url'];
	if($rs['episode_type'] == 2 || $rs['episode_type'] == 3) 
		$url = $url;
	elseif($rs['episode_type'] == 5) 
		if (preg_match("#youtube.com/([^/]+)#",$url)) {
		$url = get_link_total($url,0).'&stretching=exactfit&volume=100';
		}
		else{
			$url = $web_link.'/'.'player.swf?file='.$url.'&stretching=exactfit&volume=100';
		}
	else $url = get_link_total($url,0);
	$player = str_replace('type=video&autostart=true&','',$url);
	if (substr_count($player ,$web_link.'/'.'player.swf')!=0){
		$player=$player.'&plugins=captions-1&captions.file='.$web_link.'/'.'captions.xml&captions.back=ffff';
		$player=$player.'&autostart=false';
	}
	header("Location: ". $player);
}
?>
