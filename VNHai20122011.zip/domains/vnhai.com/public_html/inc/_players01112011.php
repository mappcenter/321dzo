<?php
if (!defined('IN_MEDIA')) die("Hack");
function players($url,$type,$width,$height){
    global $web_link;
	$url = get_link_total($url);
		if ($type==3)
		   $player = "<OBJECT type=\"application/x-oleobject\" CLASSID=\"CLSID:6BF52A52-394A-11D3-B153-00C04F79FAA6\" codebase=\"http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=5,1,52,701\" width=\"$width\" height=\"$height\"><param name=\"url\" value=\"$url\"><param name=\"stretchToFit\" value=\"true\"><PARAM name=\"EnableContextMenu\" value=\"0\"><param NAME=\"volume\" VALUE=\"100\"><EMBED type=\"application/x-mplayer2\" quality=\"high\" pluginspage=\"http://www.microsoft.com/Windows/MediaPlayer/\" file=\"$url\" src=\"$url\" WIDTH=\"$width\" HEIGHT=\"$height\" AutoStart=\"1\" EnableContextMenu=\"0\" Mute=\"0\" volume=\"100\" stretchToFit=\"true\" ShowStatusBar=\"1\"></OBJECT>";
		elseif ($type==5) 
			$player = "<embed type=\"application/x-shockwave-flash\" src=\"".$web_link."/player.swf\" width=\"$width\" height=\"$height\" id=\"mpl\" name=\"mpl\" quality=\"high\" allowfullscreen=\"true\" allowscriptaccess=\"always\" flashvars=\"file=$url&skin=skin.swf&logo=images/logo.png&volume=100\">";	
		elseif ($type==4 || $type==6 || $type==7)
			$player = "<embed width=\"595\" height=\"450\" wmode=\"transparent\" allowfullscreen=\"true\" allowscriptaccess=\"always\" type=\"application/x-shockwave-flash\" src=\"http://vnhai.com/flvplayer/mediaplayer.swf?file=$url&amp;pathlateral=true&amp;type=video&amp;\">";
		elseif ($type==8)
			$player = "<embed width=\"595\" height=\"450\" wmode=\"transparent\" allowfullscreen=\"true\" allowscriptaccess=\"always\" type=\"application/x-shockwave-flash\" src=\"http://vnhai.com/flvplayer/mediaplayer.swf?file=$url&amp;pathlateral=true&amp;type=video&amp;\">";
		elseif ($type==9)
			$player = "<object width=\"650\" height=\"550\">  <param name=\"movie\" value=\"$url\" />  <param name=\"quality\" value=\"high\" />  <param name=\"wmode\" value=\"transparent\" />  <param name=\"allowscriptaccess\" value=\"always\" />  <embed src=\"$url\" allowscriptaccess=\"always\" quality=\"high\" wmode=\"transparent\" type=\"application/x-shockwave-flash\" width=\"650\" height=\"550\"></embed></object>";
		else 
			{
				$p=explode('?',$url);
				$player="<script type=\"text/javascript\">
					var so = new SWFObject('$p[0]','mpl','$width','$height','9','#FFF');  
					so.addParam('allowscriptaccess','always');  
					so.addParam('bgcolor','#FFF'); 
					so.addParam('allowfullscreen','true');  
					so.addParam('flashvars','$p[1]');
					so.write('KGTPlayer');
				</script>";
			
			}
			
  return $player;
}
?>