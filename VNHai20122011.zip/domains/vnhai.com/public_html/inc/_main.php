<?php
if (!defined('IN_MEDIA')) die("Hack");
function box_header() {

$html="";
$header_file = file_get_contents('../header.html');
$html=$header_file."<script>kgtmenu_selectfunc(13);</script>";
return $html;

}

function box_footer() {

$html="";

$header_file = file_get_contents('../footer.html');
$html=$header_file;
return $html;

}

function box_chat() {
	global $temp;
	    $main = $temp->get_htm('chatbox');
    return $main;

}
function cat() {
	global $mysql,$temp,$tb_prefix,$link_href;
	$link_href=".";
	$q = $mysql->query("SELECT * FROM ".$tb_prefix."cat ORDER BY cat_order ASC");
	$htm = $temp->get_htm('cat_menu');
	$h['row'] = $temp->get_block_from_htm($htm,'cat_menu.row',1);	
	if (!$mysql->num_rows($q)) return ''; 
	$i = 0;
	while ($r = $mysql->fetch_array($q)) {
		$main .= $temp->replace_value($h['row'],
			array(
				'cat.URL'  => $link_href.'/category/'.$r['cat_id'].'/'.replace($r['cat_name_ascii']),
				'cat.NAME' => $r['cat_name'],
				'cat.TOTAL_FILM' => get_total('film','film_id',"WHERE film_cat = '".$r['cat_id']."'"),
			)
		);
		$i++;
	}
	$main = $temp->replace_blocks_into_htm($htm,array(
		'cat_menu' 		=> $main
		)
	);
	return $main;
}

function user_login() {
	global $mysql,$temp,$tb_prefix,$link_href;
	
	$link_href=".";
	$isLoggedIn=m_checkLogin();
	if ($isLoggedIn) {
		$q = $mysql->query("SELECT user_name,user_fullname,user_avatar FROM ".$tb_prefix."user WHERE user_id = '".$_SESSION['user_id']."'");
		$r = $mysql->fetch_array($q);
		if ($r['user_avatar']=="") $avatar="./no-avatar.gif";
		else $avatar=$r['user_avatar'];
		$htm = $temp->get_htm('user_login');
		$main = $temp->replace_value($htm,array(
			'name' 		=> $r['user_name'],
			'fullname' 		=> $r['user_fullname'],
			'avatar' 		=> $avatar,
			)
		);
	}else{
		$main = $temp->get_htm('user_notlogin');
	}
	return $main;
}

function country() {
	global $mysql,$temp,$tb_prefix,$link_href,$cacheFile;
	$link_href=".";
	$q = $mysql->query("SELECT * FROM ".$tb_prefix."country ORDER BY country_order ASC");
	$htm = $temp->get_htm('country_menu');
	$h['row'] = $temp->get_block_from_htm($htm,'country_menu.row',1);	
	if (!$mysql->num_rows($q)) return ''; 
	$i = 0;
	while ($r = $mysql->fetch_array($q)) {
		$main .= $temp->replace_value($h['row'],
			array(
				'country.URL'  => $link_href.'/country/'.$r['country_id'].'/'.replace($r['country_name_ascii']),
				'country.NAME' => $r['country_name'],
				'country.TOTAL_FILM' => get_total('film','film_id',"WHERE film_country = '".$r['country_id']."'"),
			)
		);
		$i++;
	}
	$main = $temp->replace_blocks_into_htm($htm,array(
		'country_menu' 		=> $main
		)
	);
	return $main;
}

function film($type, $number = 5, $apr = 1, $cat_id = '', $page = 1) {
	global $mysql, $temp, $tb_prefix, $link_href, $r_s_img, $value;
	$link_href=".";
	if (!$page) $page = 1;
	$limit = ($page-1)*$number;	
    if ($type == 'new') {
	$where_sql = ""; $order_sql = "ORDER BY film_id";
	$num = 1; $file_name = 'new_film';
	}
	elseif ($type == 'top') {
	$where_sql = "WHERE film_viewed_day > 0"; $order_sql = "ORDER BY film_viewed_day";
	$num = 2; $file_name = 'top_film';
	}
	elseif ($type == 'rand') {
	$where_sql = ""; $order_sql = "ORDER BY RAND()";
	$file_name = 'rand_film';
	}
	elseif ($type == 'rate') {
	//$where_sql = "WHERE film_rating_total >= 1"; $order_sql = "ORDER BY film_id";
	$where_sql = "WHERE film_rating_total >= 1"; $order_sql = "ORDER BY film_rating_total ";
	$num = 4; $file_name = 'rate_film';
	}
	elseif ($type == 'relate') {
	$where_sql = "WHERE film_cat = $cat_id"; $order_sql = "ORDER BY film_id";
	$num = 5; $file_name = 'relate_film';
	}
	elseif ($type == 'phimle') {
	$where_sql = "WHERE film_lb = 0"; $order_sql = "ORDER BY film_id";
	$num = 6; $file_name = 'phim_le';
	}
	elseif ($type == 'phimbo') {
	$where_sql = "WHERE film_lb = 1"; $order_sql = "ORDER BY film_id";
	$num = 7; $file_name = 'phim_bo';
	}
	elseif ($type == 'dangchieurap') {
	$where_sql = "WHERE film_type = 2"; $order_sql = "ORDER BY film_id";
	$num = 8; $file_name = 'phim_dang_chieu_rap';
	}
	elseif ($type == 'sapchieurap') {
	$where_sql = "WHERE film_type = 3"; $order_sql = "ORDER BY film_id";
	$num = 9; $file_name = 'phim_sap_chieu_rap';
	}	
	elseif ($type == 'decu') {
	$where_sql = "WHERE film_type = 1"; $order_sql = "ORDER BY film_id";
	$num = 10; $file_name = 'phim_de_cu';
	}	
	if ($type == 'new_right') {
	$where_sql = ""; $order_sql = "ORDER BY film_id";
	$num = 11; $file_name = 'new_film_right';
	}
	$htm = $temp->get_htm($file_name);
	$h['end_tag'] = $temp->get_block_from_htm($htm,$file_name.'.end_tag',1);
	$h['row'] = $temp->get_block_from_htm($htm,$file_name.'.row',1);
	$query = $mysql->query("SELECT * FROM ".$tb_prefix."film $where_sql $order_sql DESC LIMIT ".$limit.",$number");
	$total = get_total("film","film_id","$where_sql $order_sql");
    if (!$mysql->num_rows($query) || ($type == 'dangchieurap' && $value[1]!='')  || ($type == 'sapchieurap' && $value[1]!='') || ($type == 'rate' && $value[1]!='')) return ''; 
	$i = 0;
	while ($rs = $mysql->fetch_array($query)) {
	    $film_img = check_img($rs['film_img']);
	    $film_year = check_data($rs['film_year']);
	    $film_time = check_data($rs['film_time']);
	    $film_area = check_data($rs['film_area']);
	    $film_director = check_data($rs['film_director']);
	    $film_actor = check_data($rs['film_actor']);
	    $film_cat = check_data(get_data('cat_name','cat','cat_id',$rs['film_cat']));
		rating_img($rs['film_rating'],$rs['film_rating_total']);
	    $rater_stars_img = $r_s_img;
		if ($h['start_tag'] && fmod($i,$apr) == 0) $main .= $h['start_tag'];
		$main .= $temp->replace_value($h['row'],
			array(
				'film.ID'			=> $rs['film_id'],
				'film.URL'			=> $link_href."/info/".$rs['film_id']."/".replace(trim($rs['film_name_ascii'])),
				//'film.CUT_NAME'	=> get_words($rs['film_name'],3), //Rut Gon Title
				'film.CUT_NAME'		=> trim($rs['film_name']),
				//'film.NAME'		=> $rs['film_name']." || ".$rs['film_name_real'],
				'film.NAME'			=> $rs['film_name'],
				'film.ACTOR'		=> $film_actor,
			    'film.DIRECTOR'		=> $film_director,
			    'film.YEAR'			=> $film_year,
			    'film.TIME'			=> $film_time,
			    'film.AREA'			=> $film_area,
			    'film.CAT'			=>  $film_cat,
     		    'film.VIEWED' 		=> $rs['film_viewed'],
			    'film.VIEWED_DAY' 	=> $rs['film_viewed_day'],
				'film.IMG'			=> check_img($rs['film_img']),
				'rate.IMG'			=>	$rater_stars_img,
				'rate.VIEWED'		=>	$rs['film_rating_total'],
		    )
		);
		if ($h['end_tag'] && fmod($i,$apr) == $apr - 1) $main .= $h['end_tag'];
		$i++;
	}
	if ($h['end_tag'] && fmod($i,$apr) != $apr - 1) $main .= $h['end_tag'];
	$main = $temp->replace_blocks_into_htm($htm,array(
		'film_menu' 		=> $main
		)
	);
	$main = $temp->replace_value($main,array(
			'TOTAL'			=> $total,
			'pages.FILM'		=> view_pages('film',$total,$number,$page,$num,$apr,$cat_id),
		)
	);
	
	return $main;
}

function trailer($num = 10,$apr = 1,$page = 1) {
	global $mysql, $temp, $tb_prefix, $link_href;
	if (!$page) $page = 1;
	$limit = ($page-1)*$num;
    $query = $mysql->query("SELECT * FROM ".$tb_prefix."trailer ORDER BY trailer_id DESC LIMIT ".$limit.",$num");
	$total = get_total("trailer","trailer_id");	
	$htm = $temp->get_htm('trailer');
	$h['end_tag'] = $temp->get_block_from_htm($htm,'trailer.end_tag',1);
	$h['row'] = $temp->get_block_from_htm($htm,'trailer.row',1);
	if (!$mysql->num_rows($query)) return ''; 
	$i = 0;
	while ($rs = $mysql->fetch_array($query)) {
		if ($h['start_tag'] && fmod($i,$apr) == 0) $main .= $h['start_tag'];
		$main .= $temp->replace_value($h['row'],
			array(
				'trailer.CUT_NAME'		=> get_words($rs['trailer_name'],3),
				'trailer.NAME'		=> $rs['trailer_name'],
				'trailer.IMG'			=> check_img($rs['trailer_img']),
				'trailer.ID'			=> $rs['trailer_id'],
				'trailer.URL'			=> "?trailer=".$rs['trailer_id'],
			)
		);
		if ($h['end_tag'] && fmod($i,$apr) == $apr - 1) $main .= $h['end_tag'];
		$i++;
	}
	if ($h['end_tag'] && fmod($i,$apr) != $apr - 1) $main .= $h['end_tag'];
	$main = $temp->replace_blocks_into_htm($htm,array(
		'trailer_menu' 		=> $main
		)
	);
	$main = $temp->replace_value($main,array(
	    'pages.TRAILER' => view_pages('trailer',$total,$num,$page,$apr),
			
		)
	);	
	return $main;
}

function news($num=10,$apr=1) {
	global $mysql, $temp, $tb_prefix,$link_href;
	$link_href=".";
	$file_name = 'news';
	$htm = $temp->get_htm($file_name.'_menu');
	$h['end_tag'] = $temp->get_block_from_htm($htm,'news_menu.end_tag',1);
	$h['row'] = $temp->get_block_from_htm($htm,'news_menu.row',1);
	$q = $mysql->query("SELECT * FROM ".$tb_prefix."news ORDER BY news_id DESC LIMIT $num");
	$i = 0;
	while ($rs = $mysql->fetch_array($q)) {
        if ($h['start_tag'] && fmod($i,$apr) == 0) $main .= $h['start_tag'];
		$main .= $temp->replace_value($h['row'],
			array(
				'news.ID'			=> $rs['news_id'],
				'news.URL'			=> $link_href."/news/".$rs['news_id']."/".replace($rs['news_name_ascii']),
				'news.CUT_NAME'		=> $rs['news_name'],
				'news.NAME'			=> $rs['news_name'],
				'news.IMG'			=> check_img($rs['news_img']),
				)
		);
		if ($h['end_tag'] && fmod($i,$apr) == $apr - 1) $main .= $h['end_tag'];
		$i++;
	}
	if ($h['end_tag'] && fmod($i,$apr) != $apr - 1) $main .= $h['end_tag'];
	$main = $temp->replace_blocks_into_htm($htm,array(
		'news_menu' 		=> $main
		)
	);
	return $main;
}

function support() {
	global $temp;
		$main = $temp->get_htm('support');
	return $main;
}

function search() {
	global $temp;
	    $main = $temp->get_htm('search');
    return $main;
}

function adv() {
	global $temp;
	    $main = $temp->get_htm('adv');
    return $main;
}
function adv_info() {
	global $temp;
	    $main = $temp->get_htm('adv_info');
    return $main;
}
function adv_rand() {
	global $temp;
	    $main = $temp->get_htm('adv_rand');
    return $main;
}
function adv_right() {
	global $temp;
	    $main = $temp->get_htm('adv_right');
    return $main;
}
function adv_facebook() {
	global $temp;
	    $main = $temp->get_htm('adv_facebook');
    return $main;
}
function adv_hosting() {
	global $temp;
	    $main = $temp->get_htm('adv_hosting');
    return $main;
}

function comment($number,$file_name = 'new_comment') {
	global $mysql, $temp, $tb_prefix,$link_href;
	$result = $mysql->query("SELECT *  FROM ".$tb_prefix."comment ORDER BY comment_id DESC");
	$main = $temp->get_htm($file_name);
	$t['link'] = $temp->get_block_from_htm($main,$file_name.'.row',1);
	$n = 0;
	$num = 0;
	$limit = $mysql->num_rows($result);
	if (!$mysql->num_rows($result))  return ''; 
	else
		while ($n < $limit) {
			$r = $mysql->fetch_array($result);
			$n++;
			$comment_film_id_now = " ".$r['comment_film']." ";
			if (!ereg("$comment_film_id_now","$list_comment_film_id_pre")) {
				$result2 = $mysql->query("SELECT * FROM ".$tb_prefix."film WHERE film_id = '".$r['comment_film']."' ORDER BY film_id ASC");
				$r2 = $mysql->fetch_array($result2);
				$film_cut_name = get_words($r2['film_name'],5);
				$film_name = $r2['film_name'];
				$film_name_ascii = replace($r2['film_name_ascii']);
				$content = emotions_replace(bad_words(un_htmlchars(text_tidy($r['comment_content'], 500, 1))));  if ($content) {
					$num++;
					$comment_film_id_pre = $r['comment_film'];
					$list_comment_film_id_pre = $list_comment_film_id_pre." ".$r['comment_film']." ";
					$html .= $temp->replace_value($t['link'],
						array(
				            'film.URL'		=> $link_href."/info/".$r['comment_film']."/".$film_name_ascii,
							'comment.POSTER'	=>	trim(bad_words($r['comment_poster'])),
							'comment.CONTENT'	=>	$content,
							'comment.ID'	=>	$r['comment_id'],
							'film.CUT_NAME'	=>	$film_cut_name,
							'film.NAME'	=>	$film_name,
						   )
					);
					if ( $number - 1 < $num ) $n = $limit + 10;
				}
				
			}
		}
	$main = $temp->replace_blocks_into_htm($main,array(
		$file_name	=>	$html
		)
	);
	return $main;
}

function announcement() {
	global $mysql, $temp, $tb_prefix;
	    $htm = $temp->get_htm('announcement');
	    $contents = get_data('cf_announcement','config','cf_id',1);
	    $contents = text_tidy($contents);
	    if (!$contents) return '';
	    $main .= $temp->replace_value($htm,
		    array(
			     'ann.CONTENT'	=>	$contents,
		    )
	    );
	return $main;
}

function request($num = 5,$page = 1) {
    global $mysql,$tb_prefix,$temp; 
	if (!$page) $page = 1;
	$limit = ($page-1)*$num;
	$main = $temp->get_htm('request');	
	$q = $mysql->query("SELECT * FROM ".$tb_prefix."request ORDER BY request_id DESC LIMIT ".$limit.",$num");
	$total = get_total("request","request_id");
	if ($total) {
		$request_block = $temp->get_block_from_htm($main,'request_block');
		$request = $temp->get_block_from_htm($request_block,'request',1);		
		$html = '';
		$i = 0;
		while ($r = $mysql->fetch_array($q)) {
			$i++;
			$html .= $temp->replace_value($request,
				array(
					'request.POSTER_CUT'	=>	bad_words(cut_string($r['request_email'],15)),
					'request.POSTER'	=>	$r['request_email'],
					'request.NAME'		=>	bad_words($r['request_name']),
				)
			);
		}
		
	}
    $main = $temp->replace_blocks_into_htm($main,array(
		'request_block'	=>	$html,
		)
	);
	$main = $temp->replace_value($main,array(
		'limit.REQUEST' => $num,
		'pages.REQUEST' => view_pages('request',$total,$num,$page),
		)
	);
  return $main;
}
function write_comment($num=10,$film_id,$page){
    global $mysql,$tb_prefix,$temp,$isLoggedIn; 
	if (!$page) $page = 1;
	$limit = ($page-1)*$num;
	$main = $temp->get_htm('comment');	
	$q = $mysql->query("SELECT * FROM ".$tb_prefix."comment WHERE comment_film = $film_id ORDER BY comment_time DESC LIMIT ".$limit.",$num");
	$total = get_total("comment","comment_id","WHERE comment_film = $film_id");
	if ($total) {
		$comment_block = $temp->get_block_from_htm($main,'comment_block');
		$comment = $temp->get_block_from_htm($comment_block,'comment',1);		
		$html = '';
		$unset = false;
		$i = 0;
		while ($r = $mysql->fetch_array($q)) {
			$i++;
			$content = emotions_replace(un_htmlchars(text_tidy($r['comment_content'])));
			$html .= $temp->replace_value($comment,
				array(
					'comment.POSTER'	=>	trim(bad_words($r['comment_poster'])),
					'comment.TIME'		=>	date('d-m-Y',$r['comment_time']),
					'comment.CONTENT'	=>	$content,
					'comment.ID'	=>	$r['comment_id'],
				)
			);
		}
		
	}
	else $html = '&nbsp;&nbsp;Chưa có cảm nhận nào. Cảm nhận của bạn sẽ là <b>cảm nhận đầu tiên</b> đấy nhé!';
	
	if (!$isLoggedIn){
		$check_login_value="<i><b>Hãy <a href='./members/login.html'>đăng nhập</a> trước khi viết cảm nhận. Nếu bạn chưa có tài khoản, hãy <a href='./members/register.html'>đăng ký</a> ngay một tài khoản để sử dụng, hoặc nhập đúng mã số hiện trong ảnh để có thể đăng cảm nhận của bạn về phim này.</b></i><br/>";
		$check_login_name="Tên của bạn";
		$show='';
	}else{
		$check_login_name=$_SESSION['user_name'];
		$show='none';
	}
    $main = $temp->replace_blocks_into_htm($main,
		array(
			'comment_block'	=>	$html,
		)
	);
	$main = $temp->replace_value($main,
		array(
			'film.ID'	=>	$film_id,
			'film.NAME' => get_data("film_name","film","film_id","$film_id"),
			'limit.COMMENT'	=>	$num,
			'check_value' =>$check_login_value,
			'check_name' =>$check_login_name,
			'show' =>$show,
			'pages.COMMENT' => view_pages('comment',$total,$num,$page,$film_id),
		)
	);
  return $main;
} 
?>