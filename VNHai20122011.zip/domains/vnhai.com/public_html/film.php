<?php
if (!defined('IN_MEDIA')) die("Hack");
#######################################
# LIST
#######################################
// SEO Link 
$link_href=".";
if ($value[1]=='list' || $value[1]=='search' || $value[1]=='quick_search' || $value[1]=='category' || $value[1]=='country') {
    if ($value[1]=='list') {
	    if (!$value[2] || $value[2] == '') $value[2] = 'new';
		$where_sql = '';
		$order = $value[2];
		$page = $value[3];
		if($value[2] == 'rate'){
			$link_page = $link_href.'/hai-hay-nhat/trang-';
		}elseif ($value[2] == 'view') {
			$link_page = $link_href.'/xem-nhieu/trang-';
		}else{
			$link_page = $link_href.'/hai-moi-nhat/trang-';
		}
	}
	elseif ($value[1]=='search') {	
	    $kw = urldecode($value[2]);
		$where_sql = "WHERE film_name_ascii LIKE '%".$kw."%' OR film_name LIKE '%".$kw."%' OR film_name_real LIKE '%".$kw."%' OR film_actor LIKE '%".$kw."%' OR film_director LIKE '%".$kw."%'";
		$page = $value[3];
		$title_name = $title_web = "KẾT QUẢ TÌM KIẾM THEO TỪ KHÓA: ".Unistr($kw)."";
		$link_page = $link_href.'/'.$value[1].'/'.$value[2].'/';
	}
	elseif ($value[1]=='quick_search') {
	    $kw = urldecode($value[2]);
		if ($value[2] == "0-9") $where_sql = "WHERE film_name_ascii RLIKE '^[0-9]'";
		else $where_sql = "WHERE film_name_ascii LIKE '".$kw."%'";
		$title_name = $title_web = "TÌM KIẾM NHANH";
		$page = $value[3];
		$link_page = $link_href.'/'.$value[1].'/'.$value[2];
	}
	elseif ($value[1]=='category') {
	    $cat_id = intval($value[2]);
		$where_sql = "WHERE film_cat = $cat_id";
		$page = $value[4];
		$title_name = $title_web = "THỂ LOẠI: ".get_data('cat_name','cat','cat_id',$value[2]);
		$link_page = $link_href.'/'.$value[1].'/'.$value[2].'/'.$value[3].'/';
	}
	elseif ($value[1]=='country') {
	    $country_id = intval($value[2]);
		$where_sql = "WHERE film_country = $country_id";
		$page = $value[4];
		$title_name = $title_web = "PHIM: ".get_data('country_name','country','country_id',$value[2]);
		$link_page = $link_href.'/'.$value[1].'/'.$value[2].'/'.$value[3].'/';
	}
	if ($order=='view'){
	$order_sql = 'WHERE film_viewed > 0 ORDER BY film_viewed DESC';
	$title_list = "XEM NHIỀU NHẤT";
	}
	elseif ($order == 'top-day') {
	$order_sql = "WHERE film_viewed_day > 0 ORDER BY film_viewed_day";
	$title_list = "XEM NHIỀU TRONG NGÀY";
	}
	elseif ($order=='rate'){ 
	$order_sql = "WHERE film_rating_total > 0 ORDER BY film_rating_total DESC";
	$title_list = "BÌNH CHỌN NHIỀU NHẤT";
	}
	elseif ($order == 'phim-dien-anh') {
	$order_sql = "WHERE film_lb = 0 ORDER BY film_id";
	$title_list="PHIM ĐIỆN ẢNH MỚI";
	}
	elseif ($order == 'phim-bo') {
	$order_sql = "WHERE film_lb = 1 ORDER BY film_id";
	$title_list="PHIM BỘ MỚI";
	}
	elseif ($order == 'phim-de-cu') {
	$order_sql = "WHERE film_type = 1 ORDER BY film_id";
	$title_list="PHIM ĐỀ CỬ";
	}
	else{ 
	$order_sql = 'ORDER BY film_id DESC';
	$title_list = "MỚI CẬP NHẬT";
	}
	$file_name = 'list';	
	$htm = $temp->get_htm($file_name);
	$page_size = $per_page;
	if (!$page) $page = 1;
	$limit = ($page-1)*$page_size;

	$h['num_tag'] = $temp->get_block_from_htm($htm,'num_tag',1);
	$h['start_tag'] = $temp->get_block_from_htm($htm,'start_tag',1);
	$h['end_tag'] = $temp->get_block_from_htm($htm,'end_tag',1);
	$h['row'] = $temp->get_block_from_htm($htm,'row',1);
	$q = $mysql->query("SELECT * FROM ".$tb_prefix."film $where_sql $order_sql LIMIT ".$limit.",".$page_size);
	$total = get_total("film","film_id","$where_sql $order_sql");
	if ($total){
	if ($value[1]=='list') $title_web = $title_name = "DANH SÁCH PHIM ".$title_list;
	while ($rs = $mysql->fetch_array($q)) {
	   static $i = 0;
        rating_img($rs['film_rating'],$rs['film_rating_total']);
		$rater_stars_img = $r_s_img;		
		if ($h['start_tag'] && fmod($i,$h['num_tag']) == 0) $main .= $h['start_tag'];
		$main .= $temp->replace_value($h['row'],
			array(
				'film.ID'			=> $rs['film_id'],
				'film.URL'			=> $link_href."/info/".$rs['film_id']."/".replace($rs['film_name_ascii']),
				'film.CUT_NAME'		=> trim($rs['film_name']),
				'film.NAME'			=> $rs['film_name']." || ".$rs['film_name_real'],
				'film.VIEWED'		=> $rs['film_viewed'],
				'film.IMG'			=> check_img($rs['film_img']),
				'rate.IMG'			=> $rater_stars_img,
				'rate.VIEWED'		=> "( <b>".$rs['film_rating_total']."</b> rates)",
			)
		);
		if ($h['end_tag'] && fmod($i,$h['num_tag']) == $h['num_tag'] - 1) $main .= $h['end_tag'];
		$i++;
	}
	$main = $temp->replace_blocks_into_htm($htm,array(
		'film_list' 		=> $main
		)
	);
	$main = $temp->replace_value($main,
		array(
			'title.NAME'		=> $title_name,
			'TOTAL'				=> $total,
			'VIEW_PAGES'		=> view_pages('film',$total,$page_size,$page,$link_page),
		)
	);
	$web_keywords_main = $web_title_main = $title_web." || ";
  }
  else 
  //header("Location: ".$link_href.'/error/');
  header("Location: $web_link/error.html");
}

#######################################
# INFO
#######################################
elseif ($value[1]=='info' && is_numeric($value[2])) {
	$film_id = intval($value[2]);
	$q = $mysql->query("SELECT * FROM ".$tb_prefix."film WHERE film_id = '$film_id'");
	$num = $mysql->num_rows($q);
	if (!$num) header("Location: $web_link/error.html");
	$r = $mysql->fetch_array($q);
	$film_viewed = $rs['album_viewed'];	
	$mysql->query("UPDATE ".$tb_prefix."film SET film_viewed = film_viewed + 1, film_viewed_day = film_viewed_day + 1 WHERE film_id = '".$film_id."'");	
	$episode = $mysql->fetch_array($mysql->query("SELECT * FROM ".$tb_prefix."episode WHERE episode_film = '".$film_id."' ORDER BY episode_id ASC LIMIT 0,1"));
	$film_img = check_img($r['film_img']);
    $film_info = text_tidy($r['film_info']);
	$film_year = check_data($r['film_year']);
	$film_time = check_data($r['film_time']);
	$film_area = check_data($r['film_area']);
	$film_director = check_data($r['film_director']);
	$film_actor = splitlink(check_data($r['film_actor']),'tag','');
	//$film_cat = $link_href.'/category/'.$r['film_cat'].'/'.check_data(get_data('cat_name','cat','cat_id',$r['film_cat'])).'.html';
	$film_cat = '<a title="'.check_data(get_data('cat_name','cat','cat_id',$r['film_cat'])).'" href="'.$link_href.'/category/'.$r['film_cat'].'/'.replace(get_ascii(check_data(get_data('cat_name_ascii','cat','cat_id',$r['film_cat'])))).'" style="">'.check_data(get_data('cat_name','cat','cat_id',$r['film_cat'])).'</a>';
	$film_country = check_data(get_data('country_name','country','country_id',$r['film_country']));
	$link_seo=$link_href.'/watch/'.$episode['episode_id'].'/'.replace($r['film_name_ascii']);
	$htm = $temp->get_htm('info');
	$main = $temp->replace_value($htm,array(
			'film.ID'		=> $r['film_id'],
			'cat.ID'		=> $r['film_cat'],
			'episode.ID'	=> $episode['episode_id'],
			'episode.PLAY'	=> $link_seo,
			'film.IMG'		=> $film_img,
			'film.NAME'		=> $r['film_name'].' || '.$r['film_name_real'],
			'film.WATCH'	=> $link_seo,
			'film.ACTOR'	=> $film_actor,
			'film.COUNTRY'	=> $film_country,
			'film.DIRECTOR'	=> $film_director,
			'film.YEAR'		=> $film_year,
			'film.TIME'		=> $film_time,
			'film.AREA'		=> $film_area,
			'film.CAT'		=> $film_cat,
     		'film.VIEWED' 	=> $r['film_viewed'],
			'film.INFO'		=> $film_info,
			'episode.URL' 	=> "?episode=".$episode['episode_id'],
			'film.LINK'		=> $web_link.'/info/'.$r['film_id'].'/'.replace($r['film_name_ascii']),
			)
		);
	$web_keywords_main = $web_title_main = 'Xem Phim Hài : '.check_data($r['film_name'])." | ".check_data($r['film_name_ascii'])." | ".check_data($r['film_name_real'])." || ";
}

#######################################
# WATCH
#######################################
elseif (($value[1]=='watch' && is_numeric($value[2])) || $_POST['watch']) {
if($_SERVER['REQUEST_METHOD'] == "POST") $episode_id = (int)$_POST['episode_id'];
else $episode_id = $value[2];
$q = $mysql->query("SELECT * FROM ".$tb_prefix."episode WHERE episode_id = $episode_id ");
$rs = $mysql->fetch_array($q); $num = $mysql->num_rows($q); 
#######################################
# PLAY
#######################################
if ($num){
    # select info film
	$film = $mysql->fetch_array($mysql->query("SELECT film_id, film_name, film_name_ascii, film_name_real, film_rating, film_rating_total, film_viewed FROM ".$tb_prefix."film WHERE film_id = '".$rs['episode_film']."'"));
	if ($film['film_rating_total'] == 0) $rate_text = "BÌNH CHỌN";
	else $rate_text = "<br>".$film['film_rating']." Star | ".$film['film_rating_total']." Rates";
	rating_img($film['film_rating'],$film['film_rating_total']);
	$rater_stars_img = $r_s_img; $film_id = $film['film_id'];
	# select info episode
	if($rs['episode_local']) $url = get_data('local_link','local','local_id',$rs['episode_local']).$rs['episode_url'];
	elseif($rs['episode_type'] == 2 || $rs['episode_type'] == 3 || $rs['episode_type'] == 5) 
	$url = $rs['episode_url'];
	else {
	//$url = get_link_total($rs['episode_url']);
	$url = $rs['episode_url'];
	}
	$link_seo=$web_link.'/watch/'.$episode_id.'/'.replace($film['film_name_ascii']);
	$player = players($url,$rs['episode_type'],580,420); 
	$total_episodes = get_total("episode","episode_id","WHERE episode_film = $film_id"); 	
	$link_down=get_link_total($url,1);
	$htm = $temp->get_htm('watch');
	$main = $temp->replace_value($htm,array(
			'player'		=> $player,
			'episode.ID'		=> $episode_id,
			'film_id'		=> $film['film_id'],
			'film_name'		=> get_words($film['film_name'],8).' || '.get_words($film['film_name_real'],8),
			'url_goc'	=>	$url,
			'url_down' => $link_down,
			'send'	=>	$web_link.'/watch/'.$episode_id.'/'.replace($film['film_name_ascii']),
			'share'	=>	$web_link.'/ep/'.$episode_id,
			'info'	=>	$web_link.'/info/'.$film['film_id'].'/'.replace($film['film_name_ascii']),
			'skin' => $_SESSION['skin_folder'],
			'episode.URL' => "?episode=".$episode_id,
			'total_episodes' => $total_episodes,
			'rate' => $rater_stars_img,//." <font color=\"#F5AA59\" size=\"3\"><b>".$rate_text."</b></font>",
			'comment' => write_comment(7,$film_id,1),
			'any_episodes' => episode_show($total_episodes,$film_id,$episode_id,$rs['episode_name']),
			'blog'	=>	$blog,
			'forum'	=>	$forum,
			)
		);
	if($_SERVER['REQUEST_METHOD'] == "POST") echo $main;
	$web_title_main = 'Xem phim hài '.check_data($film['film_name'])." Tập " .$rs['episode_name']." || Watch  ".check_data($film['film_name_real'])." Episode " .$rs['episode_name']. " || ";
}
elseif (!$num) 
//header("Location: ".$link_href.'/error/');
header("Location: $web_link/error.html");
#keywords to set SEO
$web_titles = $web_title_main.$web_title; 
$web_keywords = $web_keywords_main.$web_keywords;
}
?>