<?php
if (!defined('IN_MEDIA')) die("Hack");
function players($url,$type,$width,$height){
    global $web_link;
	$url_org=$url;
	$url = get_link_total($url,0);
		if ($type==3)
		   $player = "<OBJECT type=\"application/x-oleobject\" CLASSID=\"CLSID:6BF52A52-394A-11D3-B153-00C04F79FAA6\" codebase=\"http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=5,1,52,701\" width=\"$width\" height=\"$height\"><param name=\"url\" value=\"$url\"><param name=\"stretchToFit\" value=\"true\"><PARAM name=\"EnableContextMenu\" value=\"0\"><param NAME=\"volume\" VALUE=\"100\"><EMBED type=\"application/x-mplayer2\" quality=\"high\" pluginspage=\"http://www.microsoft.com/Windows/MediaPlayer/\" file=\"$url\" src=\"$url\" WIDTH=\"$width\" HEIGHT=\"$height\" AutoStart=\"1\" EnableContextMenu=\"0\" Mute=\"0\" volume=\"100\" stretchToFit=\"true\" ShowStatusBar=\"1\"></OBJECT>";
		elseif ($type==5) {
			$player="<script type=\"text/javascript\">
				var so = new SWFObject('player.swf','mpl','$width','$height','9','#FFF');  
				so.addParam('allowscriptaccess','always');  
				so.addParam('bgcolor','#FFF'); 
				so.addParam('allowfullscreen','true');  
				so.addParam('flashvars','file=$url&autostart=true&volume=100');
				so.write('KGTPlayer');
			</script>";
		}
		elseif ($type==9)
		$player = "<object codebase=\"http://go.divx.com/plugin/DivXBrowserPlugin.cab\" height=\"$height\" width=\"$width\" classid=\"clsid:67DABFBF-D0AB-41fa-9C46-CC0F21721616\"><param name=\"autoplay\" value=\"true\"><param name=\"url\" value=\"$url\">
					<param name=\"custommode\" value=\"Stage6\"><param name=\"showpostplaybackad\" value=\"false\"><embed type=\"video/divx\" file=\"$url\" src=\"$url\" pluginspage=\"http://go.divx.com/plugin/download/\" showpostplaybackad=\"false\" custommode=\"Stage6\" autoplay=\"true\" height=\"$height\" width=\"$width\" /></object>";
		elseif ($type==7) $player = "<iframe allowtransparency=\"true\" style=\"border: 0px none;\" name=\"tamtayp\" id=\"tamtayp\" src=\"tamtay.php?url=$url_org\" width=\"600\" frameborder=\"0\" height=\"$height\" scrolling=\"no\"></iframe>";
		else{
			if (preg_match("#video.tamtay.vn/play/(.*?)#s", $url)){
				$player = "<iframe allowtransparency=\"true\" style=\"border: 0px none;\" name=\"tamtayp\" id=\"tamtayp\" src=\"tamtay.php?url=$url_org\" width=\"600\" frameborder=\"0\" height=\"$height\" scrolling=\"no\"></iframe>";
			}else if (preg_match("#static.yume.vn/yumevideo/(.*?)#s", $url)){
				$player = "<iframe allowtransparency=\"true\" style=\"border: 0px none;\" name=\"yume\" id=\"yume\" src=\"$url\" width=\"600\" frameborder=\"0\" height=\"$height\" scrolling=\"no\"></iframe>";
			}else{
				$p=explode('?',$url);
				$player="<script type=\"text/javascript\">
					var so = new SWFObject('$p[0]','mpl','$width','$height','9','#FFF');  
					so.addParam('allowscriptaccess','always');  
					so.addParam('bgcolor','#FFF'); 
					so.addParam('allowfullscreen','true');  
					so.addParam('flashvars','$p[1]');
					so.write('KGTPlayer');
				</script>";
			}
		}
  return $player;
}
?>