<?php
if (!defined('IN_MEDIA_ADMIN')) die("Hacking attempt");

$edit_url = 'javascript:history.go(-2)';
$edit_del = 'javascript:history.go(-1)';

$inp_arr = array(
		'name'	=> array(
			'table'	=>	'film_name',
			'name'	=>	'NAME',
			'type'	=>	'free'
		),
	    'name_real'	=> array(
			'table'	=>	'film_name_real',
			'name'	=>	'NAME REAL',
			'type'	=>	'free',
			'can_be_empty'	=> true,
		),
		'cat'	=> array(
			'table'	=>	'film_cat',
			'name'	=>	'CATEGORY',
			'type'	=>	'function::acp_cat::number',
		),
		'country'	=> array(
			'table'	=>	'film_country',
			'name'	=>	'COUNTRY',
			'type'	=>	'function::acp_country::number',
		),
		'img'	=> array(
			'table'	=>	'film_img',
			'name'	=>	'IMG',
			'type'	=>	'img',
			'can_be_empty'	=> true,
		),
		'director'	=> array(
			'table'	=>	'film_director',
			'name'	=>	'DIRECTOR',
			'type'	=>	'free',
			'can_be_empty'	=> true,
		),
		'actor'	=> array(
			'table'	=>	'film_actor',
			'name'	=>	'ACTOR',
			'type'	=>	'free',
			'can_be_empty'	=> true,
		),
	    'area'	=> array(
			'table'	=>	'film_area',
			'name'	=>	'PRODUCER',
			'type'	=>	'free',
			'can_be_empty'	=> true,
		),
		'time'	=> array(
			'table'	=>	'film_time',
			'name'	=>	'TIME',
			'type'	=>	'free',
			'can_be_empty'	=> true,
		),
		'year'	=> array(
			'table'	=>	'film_year',
			'name'	=>	'ISSUE DAY',
			'type'	=>	'free',
			'can_be_empty'	=> true,
		),
		'film_info'	=>	array(
			'table'	=>	'film_info',
			'name'	=>	'INFO',
			'type'	=>	'text',
			'can_be_empty'	=>	true,
		),
		'name_ascii'	=>	array(
			'table'	=>	'film_name_ascii',
			'type'	=>	'hidden_value',
			'value'	=>	'',
			'change_on_update'	=>	true,
		),
);
##################################################
# EDIT FILM
##################################################
if ($mode == 'edit') {
	if ($_POST['do']) {
		$arr = $_POST['checkbox'];
		if (!count($arr)) die('BROKEN');
		if ($_POST['selected_option'] == 'del') {
		if($level == 2)	acp_check_permission_mod('del_film');
			$in_sql = implode(',',$arr);
			$img = $mysql->fetch_array($mysql->query("SELECT film_img FROM ".$tb_prefix."film WHERE film_id IN (".$in_sql.")"));
			$img_remove = "../".$img[0];
			unlink($img_remove);
			$mysql->query("DELETE FROM ".$tb_prefix."episode WHERE episode_film IN (".$in_sql.")");
			$mysql->query("DELETE FROM ".$tb_prefix."film WHERE film_id IN (".$in_sql.")");
   			$mysql->query("DELETE FROM ".$tb_prefix."comment WHERE comment_film IN (".$in_sql.")");
			echo "DEL FINISH <meta http-equiv='refresh' content='0;url=".$edit_url."'>";
		}
		if($level == 2)	acp_check_permission_mod('edit_film');
		if ($_POST['selected_option'] == 'multi_edit') {
			$arr = implode(',',$arr);
			header("Location: ./?act=multi_edit_film&id=".$arr);
		}
		if($level == 2)	acp_check_permission_mod('edit_film');
		if ($_POST['selected_option'] == 'normal') {
			$in_sql = implode(',',$arr);
			$mysql->query("UPDATE ".$tb_prefix."film SET film_broken = 0 WHERE film_id IN (".$in_sql.")");
			$mysql->query("UPDATE ".$tb_prefix."episode SET episode_broken = 0 WHERE episode_film IN (".$in_sql.")");
			echo "EDIT FINISH <meta http-equiv='refresh' content='0;url=".$edit_url."'>";
		}
		if($level == 2)	acp_check_permission_mod('edit_film');
		if ($_POST['selected_option'] == 'vote') {
			$in_sql = implode(',',$arr);
			$mysql->query("UPDATE ".$tb_prefix."film SET film_type = 1 WHERE film_id IN (".$in_sql.")");
			echo "EDIT FINISH <meta http-equiv='refresh' content='0;url=".$edit_url."'>";
		}
		if($level == 2)	acp_check_permission_mod('edit_film');
		if ($_POST['selected_option'] == 'chieurap') {
			$in_sql = implode(',',$arr);
			$mysql->query("UPDATE ".$tb_prefix."film SET film_type = 2 WHERE film_id IN (".$in_sql.")");
			echo "EDIT FINISH <meta http-equiv='refresh' content='0;url=".$edit_url."'>";
		}
		if($level == 2)	acp_check_permission_mod('edit_film');
		if ($_POST['selected_option'] == 'sapchieurap') {
			$in_sql = implode(',',$arr);
			$mysql->query("UPDATE ".$tb_prefix."film SET film_type = 3 WHERE film_id IN (".$in_sql.")");
			echo "EDIT FINISH <meta http-equiv='refresh' content='0;url=".$edit_url."'>";
		}
		if($level == 2)	acp_check_permission_mod('edit_film');
		if ($_POST['selected_option'] == 'binhthuong') {
			$in_sql = implode(',',$arr);
			$mysql->query("UPDATE ".$tb_prefix."film SET film_type = 0 WHERE film_id IN (".$in_sql.")");
			echo "EDIT FINISH <meta http-equiv='refresh' content='0;url=".$edit_url."'>";
		}
		if($level == 2)	acp_check_permission_mod('edit_film');
		if ($_POST['selected_option'] == 'phimle') {
			$in_sql = implode(',',$arr);
			$mysql->query("UPDATE ".$tb_prefix."film SET film_lb = 0 WHERE film_id IN (".$in_sql.")");
			echo "EDIT FINISH <meta http-equiv='refresh' content='0;url=".$edit_url."'>";
		}
		if ($_POST['selected_option'] == 'phimbo') {
			$in_sql = implode(',',$arr);
			$mysql->query("UPDATE ".$tb_prefix."film SET film_lb = 1 WHERE film_id IN (".$in_sql.")");
			echo "EDIT FINISH <meta http-equiv='refresh' content='0;url=".$edit_url."'>";
		}		
		exit();
	}	
	elseif ($film_id) {
		if($level == 2)	acp_check_permission_mod('edit_film');
		if (!$_POST['submit']) {
			$q = $mysql->query("SELECT * FROM ".$tb_prefix."film WHERE film_id = '".$film_id."'");
			$r = $mysql->fetch_array($q);			
			foreach ($inp_arr as $key=>$arr) $$key = $r[$arr['table']];
		}
		else {
			$error_arr = array();
			$error_arr = $form->checkForm($inp_arr);
			if (!$error_arr) {
			    $inp_arr['name_ascii']['value'] = strtolower(get_ascii($name));
				$name = UNIstr($_POST['name']);
				$name_real = UNIstr($_POST['name_real']);
				if(move_uploaded_file ($_FILES['img']['tmp_name'],'../'.$img_film_folder."/".$_FILES['img']['name']))
				$img = $img_film_folder."/".$_FILES['img']['name'];
				else $img = $_POST['img'];
				$sql = $form->createSQL(array('UPDATE',$tb_prefix.'film','film_id','film_id'),$inp_arr);
				eval('$mysql->query("'.$sql.'");');
			 	echo "EDIT FINISH <meta http-equiv='refresh' content='0;url=".$edit_url."'>";
				exit();
			}
		}
		$warn = $form->getWarnString($error_arr);
		//$name = UNIstr($name);
		$form->createForm('EDIT FILM',$inp_arr,$error_arr);
	}
	else {
		if($level == 2)	acp_check_permission_mod('edit_film');
		$film_per_page = 30;
		if (!$pg) $pg = 1;
		$xsearch = strtolower(get_ascii(urldecode($_GET['xsearch'])));
		$extra = (($xsearch)?"film_name_ascii LIKE '%".$xsearch."%' OR film_name_real LIKE '%".$xsearch."%' ":'');		
		if ($cat_id) {
        $q = $mysql->query("SELECT * FROM ".$tb_prefix."film WHERE film_cat = '".$cat_id."' ".(($extra)?"AND ".$extra." ":'')."ORDER BY film_id DESC LIMIT ".(($pg-1)*$film_per_page).",".$film_per_page);
		$tt = get_total('film','film_id',"WHERE film_cat = '".$cat_id."'".(($extra)?"AND ".$extra." ":''));
		}
		elseif ($country_id) {
        $q = $mysql->query("SELECT * FROM ".$tb_prefix."film WHERE film_country = '".$country_id."' ".(($extra)?"AND ".$extra." ":'')."ORDER BY film_id DESC LIMIT ".(($pg-1)*$film_per_page).",".$film_per_page);
		$tt = get_total('film','film_id',"WHERE film_country = '".$country_id."'".(($extra)?"AND ".$extra." ":''));
		}
		elseif ($show_broken) {
        $q = $mysql->query("SELECT * FROM ".$tb_prefix."film WHERE film_broken = 1 ".(($extra)?"AND ".$extra." ":'')."ORDER BY film_id DESC LIMIT ".(($pg-1)*$film_per_page).",".$film_per_page);
		$tt = get_total('film','film_id','WHERE film_broken = 1 '.(($extra)?"AND ".$extra." ":''));
		}
		elseif ($show_film_lb !='') {
        $q = $mysql->query("SELECT * FROM ".$tb_prefix."film WHERE film_lb = ".$show_film_lb." ".(($extra)?"AND ".$extra." ":'')."ORDER BY film_id DESC LIMIT ".(($pg-1)*$film_per_page).",".$film_per_page);
		$tt = get_total('film','film_id','WHERE film_lb = '.$show_film_lb.' '.(($extra)?"AND ".$extra." ":''));
		}	
		elseif ($show_film_type) {
        $q = $mysql->query("SELECT * FROM ".$tb_prefix."film WHERE film_type = ".$show_film_type." ".(($extra)?"AND ".$extra." ":'')."ORDER BY film_id DESC LIMIT ".(($pg-1)*$film_per_page).",".$film_per_page);
		$tt = get_total('film','film_id','WHERE film_type = '.$show_film_type.' '.(($extra)?"AND ".$extra." ":''));
		}	
        else {
		$q = $mysql->query("SELECT * FROM ".$tb_prefix."film ".(($extra)?"WHERE ".$extra." ":'')."ORDER BY film_id DESC LIMIT ".(($pg-1)*$film_per_page).",".$film_per_page);
		$tt = get_total('film','film_id',"".(($extra)?"WHERE ".$extra." ":'')."");
        }
			if ($tt) {
			if ($xsearch) {
				$link2 = preg_replace("#&xsearch=(.*)#si","",$link);
			}
			else $link2 = $link;
			echo "RICHES SERIAL NUMBER FILM NEED <b>EDIT</b> <input id=film_id size=20> <input type=button onclick='window.location.href = \"".$link."&film_id=\"+document.getElementById(\"film_id\").value;' value=EDIT><br><br>";
			echo "RICHES SERIAL NUMBER FILM NEED <b>DEL</b> <input id=film_del_id size=20> <input type=button onclick='window.location.href = \"".$link."&film_del_id=\"+document.getElementById(\"film_del_id\").value;' value=DEL><br><br>";
			echo "SEARCH FILM <input id=xsearch size=20 value=\"".$xsearch."\"> <input type=button onclick='window.location.href = \"".$link2."&xsearch=\"+document.getElementById(\"xsearch\").value;' value=GO><br><br>";
			echo "<table width=90% align=center cellpadding=2 cellspacing=0 class=border><form name=media_list method=post action=$link onSubmit=\"return check_checkbox();\">";
			echo "<tr align=center><td width=3% class=title></td><td class=title width=50%>NAME</td><td class=title>TOTAL EPISODE</td><td class=title>MANAGEMENT EPISODE</td><td class=title>IMG</td><td class=title>BROKEN</td></tr>";
			while ($r = $mysql->fetch_array($q)) {
				$id = $r['film_id'];
				$film = $r['film_name'];
				$totalepisodes_of_film = get_total('episode','episode_id',"WHERE episode_film = ".$id."");
				$img = ''; if ($r['film_img']) { $img_src = $r['film_img']; if (!ereg("http://",$img_src)) $img_src = "../".str_replace(" ","%20",$img_src); $img ="<img src=".$img_src." width=50 height=50>"; }
				$broken = ($r['film_broken'])?'<font color=red><b>X</b></font>':'';
                $cat_name = check_data(get_data('cat_name','cat','cat_id',$r['film_cat']));
				echo "<tr><td align=center><input class=checkbox type=checkbox id=checkbox onclick=docheckone() name=checkbox[] value=$id></td><td class=fr><b><a href=?act=film&mode=edit&film_id=".$id.">".$film."</a></b><br><br><a href=?act=cat&mode=edit&cat_id=".$r['film_cat'].">&raquo;<i>".$cat_name."</i></a></td><td class=fr_2 align=center><b>".$totalepisodes_of_film."</b></td><td class=fr_2 align=center><a href=?act=episode&mode=edit&film_id=".$id."><b>MANAGEMENT</b></a></td><td class=fr_2 align=center>".$img."</td><td class=fr_2 align=center>".$broken."</td></tr>";
			}
			echo '<tr><td class=fr align=center><input class=checkbox type=checkbox name=chkall id=chkall onclick=docheck(document.media_list.chkall.checked,0) value=checkall></td>
			     <td colspan=5 align="center" class=fr>WITH FILMS CHOOSED '.
				'<select name=selected_option>
				<option value=del>DELETE</option>
				<option value=multi_edit>EDIT</option>
				<option value=normal>FIX BROKEN</option>
				<option value=vote>ĐỀ CỬ</option>
				<option value=chieurap>ĐANG CHIẾU RẠP</option>
				<option value=sapchieurap>SẮP CHIẾU RẠP</option>
				<option value=binhthuong>DẠNG THƯỜNG</option>
				<option value=phimle>PHIM LẺ</option>
				<option value=phimbo>PHIM BỘ</option></select>'.
				'<input type="submit" name="do" class=submit value="SEND"></td></tr>';
			echo "<tr><td colspan=6>".admin_viewpages($tt,$film_per_page,$pg)."</td></tr>";
			echo '</form></table>';
		}
		else echo "THERE IS NO FILMS";
	}
}
?>
