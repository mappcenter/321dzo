<?php
if (isset($_GET['url'])){
	echo '<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />

<style>
body {
margin: 0px;
padding: 0px;
}
a {
color: #FFF;
text-decoration: none;
}
</style>
</head>
<body topmargin="0" leftmargin="0">
<iframe ALLOWTRANSPARENCY="true" style="border:0px;" frameborder="0" scrolling="no" name="tamtayf" id="tamtayf" src="tamtay.php?url2='.$_GET['url'].'" width="700" height="440"></iframe>

</body></html>';
	}
elseif (isset($_GET['url2'])){
echo '<html>
<head>
<style>
body {
margin: 0px;
padding: 0px;
}
</style>
</head>
<body topmargin="0" leftmargin="0" onload="window.scrollTo(12,210);">
<center>
<iframe ALLOWTRANSPARENCY="true" frameborder="0" scrolling="no" name="tamtay" id="tamtay" src="'.$_GET['url2'].'" width="680" height="600"></iframe>
</center>
</body></html>';
}
?>