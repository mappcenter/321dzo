<?php
if (!defined('IN_MEDIA')) die("Hack");
if (substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) ob_start('ob_gzhandler');
else ob_start();
@session_start();
header("Content-Type: text/html; charset=UTF-8");
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
if (!ini_get('register_globals')) {
	@$_GET = $HTTP_GET_VARS;
	@$_POST = $HTTP_POST_VARS;
	@$_COOKIE = $HTTP_COOKIE_VARS;
	extract($_GET);
	extract($_POST);
}
define('NOW',time());
define('IP',$_SERVER['REMOTE_ADDR']);
define('USER_AGENT',$_SERVER['HTTP_USER_AGENT']);
define('URL_NOW',$_SERVER["REQUEST_URI"]);
if (!USER_AGENT || !IP) exit();
include('_dbconnect.php');
$mysql =& new mysql;
$mysql->connect($config['db_host'],$config['db_user'],$config['db_pass'],$config['db_name']);
#######################################
# GET DATABASE
#######################################
function get_data($f1,$table,$f2,$f2_value){
	global $mysql,$tb_prefix;
	$q = $mysql->query("SELECT $f1 FROM ".$tb_prefix.$table." WHERE $f2='".$f2_value."'");
	$rs = $mysql->fetch_array($q);
	$f1_value = $rs[$f1];
	return $f1_value;
}
#######################################
# GET CONFIG
#######################################
$web_title = get_data('cf_web_name','config','cf_id',1);
$web_link = get_data('cf_web_link','config','cf_id',1);
if ($web_link[strlen($web_link)-1] == '/') $web_link = substr($web_link,0,-1);
$web_keywords = get_data('cf_web_keywords','config','cf_id',1);
$web_email = get_data('cf_web_email','config','cf_id',1);
$per_page = get_data('cf_per_page','config','cf_id',1);
$link_href = "?movie=";
$url_load = $_GET['movie'];
$url = strtolower($url_load);
$value = array();
if ($url) $value = split('/',$url);
$img_film_folder = "images/film";
$img_ads_folder  = "images/ads";
$img_trailer_folder  = "images/trailer";
$img_news_folder  = "images/news";
$js = "<script type=\"text/javascript\" src=\"".$web_link."/js/unikey.js\"></script>
           <script type=\"text/javascript\" src=\"".$web_link."/js/load.js\"></script>
		   <script language=\"javascript\" type=\"text/javascript\" src=\"".$web_link."/js/tooltips.js\"></script>
		   <script>
		   var loadingText = \"<center><img src='".$web_link."/images/loading.gif'> <b>Đang tải dữ liệu ...</b></center>\";
           var RATE_OBJECT_IMG = \"".$_SESSION['skin_folder']."/img/rate/full.gif\";
           var RATE_OBJECT_IMG_HOVER = \"".$_SESSION['skin_folder']."/img/rate/full.gif\";
           var RATE_OBJECT_IMG_HALF = \"".$_SESSION['skin_folder']."/img/rate/half.gif\";
           var RATE_OBJECT_IMG_BG = \"".$_SESSION['skin_folder']."/img/rate/none.gif\";
           </script>";
?>