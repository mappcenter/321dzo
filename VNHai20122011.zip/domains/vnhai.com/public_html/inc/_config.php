<?php
$config['db_host']	= 'localhost';
$config['db_name'] 	= 'vnhaicom_db';
$config['db_user']	= 'vnhaicom_admin';
$config['db_pass']	= 'E7k6T9nt';
$tb_prefix			= 'table_';
include("init.php");
?>