<?php
define('IN_MEDIA',true);
include('inc/_config.php');
#######################################
# GET COOKIE
#######################################
$visit=$_SERVER['HTTP_REFERER'];
if ((preg_match('#login.ht(.*?)#s', $visit))||(preg_match('#logout.ht(.*?)#s', $visit))||(preg_match('#register.ht(.*?)#s', $visit))){
	$lastvisit=$_SESSION['last_visit'];
}else{
	$lastvisit=$visit;
	$_SESSION['last_visit']=$lastvisit;
}
/*
$movie_cookie=$_COOKIE['PHPSESSID'];
if ($movie_cookie=="") die("<html><head><title>$web_title</title><meta http-equiv='refresh' content='0'></head><body></body></html>");
*/
include('inc/_functions.php');
include('inc/_main.php');
include('inc/_string.php');
include('inc/_grab.php');
include('inc/_temp.php');
include('inc/_pages.php');
include('inc/_players.php');
$temp =& new temp;
#######################################
# GET SKIN
#######################################
$skin_folder = get_data('skin_folder','skin','skin_id',get_data('cf_skin_default','config','cf_id',1));
$_SESSION['skin_folder'] = 'skin/'.$skin_folder;
#######################################
# SITE OFF
#######################################
if (get_data('cf_site_off','config','cf_id',1) == 1) {
	echo get_data('cf_announcement','config','cf_id',1);
	exit();
}
$isLoggedIn = m_checkLogin();
#######################################
# GET FILE
#######################################
if ($_POST['showrequest']) {
    $showrequest = request($num,$page);
    $temp->print_htm($showrequest);
exit();
}
if ($_POST['showcomment']) {
    $showcomment = write_comment($num,$film_id,$page);
    $temp->print_htm($showcomment);
exit();
}
if ($_POST['showfilm']) {
   if ($num == 1) $type = 'new';
   elseif ($num == 2) $type = 'top'; 
   elseif ($num == 4) $type = 'rate';
   elseif ($num == 5) $type = 'relate'; 
   elseif ($num == 6) $type = 'phimle'; 
   elseif ($num == 7) $type = 'phimbo';
   elseif ($num == 8) $type = 'dangchieurap';  
   elseif ($num == 9) $type = 'sapchieurap';
   elseif ($num == 10) $type = 'decu';  
   elseif ($num == 11) $type = 'new_right';  
   $showfilm = film($type,$number,$apr,$cat_id,$page);
   $temp->print_htm($showfilm);
exit();
}
if ($_POST['rating'] || $_POST['comment'] || $_POST['request'] || $_POST['broken']) {
	include('post.php');
	exit();
}
if ($_POST['watch'])
{
	include('film.php');
	exit();
}
//Members
if (($_POST['reg']) || ($_POST['login']) || ($_POST['forgot'])|| ($_POST['user_edit'])) {
	include('user.php');
}
#######################################
# SET TOP OF DAY
#######################################
$day = date('d',NOW);
$current_day = get_data('cf_current_day','config','cf_id',1);
if ($day != $current_day) {
	$mysql->query("UPDATE ".$tb_prefix."film SET film_viewed_day = 0");
	$mysql->query("UPDATE ".$tb_prefix."config SET cf_current_day = ".$day." WHERE cf_id = 1");
}
#######################################
# GET VALUE
#######################################
if (in_array($value[1],array('category','watch','list','search','quick_search','info','country')))
	include('film.php');
elseif ($value[1] == 'news')
	include('news.php');
elseif ($value[1] == 'error')
	include('error.php');
elseif ($value[1] == 'user')
	include('user.php');
#######################################
# GET HTML
#######################################
    $web_titles = $web_title_main.$web_title; 
    $web_keywords = $web_keywords_main.$web_keywords;
	if (in_array($value[1],array('category','list','search','quick_search','info','country')))
		$html = $temp->get_htm('home_search');
	else if ($value[1]=='watch')
		$html = $temp->get_htm('home_watch');
	else if  (($value[1]=='user') || ($value[1]=='news'))
		$html = $temp->get_htm('home_register');
	else $html = $temp->get_htm('home');
	$html = $temp->replace_value($html,array(
			'web.TITLE'			=>	$web_titles,
			'web.KEYWORDS'		=>	$web_keywords,
			'web.JS'                => $js,
		)
	);
	$html = $temp->replace_blocks_into_htm($html,array(
			'main'		=>	$main,
		)
	);
	$temp->print_htm($html);
	exit();

?>