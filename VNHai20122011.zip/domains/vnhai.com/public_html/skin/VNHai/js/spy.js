
$(function () {
    $('div.spy').simpleSpy();
});

(function ($) {
    
$.fn.simpleSpy = function (divmit, interval) {
    divmit = divmit || 2;
    interval = interval || 5500;
    
    return this.each(function () {
        // 1. setup
            // capture a cache of all the divst items
            // chomp the divst down to divmit div elements
        var $divst = $(this),
            items = [], // uninitiadivsed
            currentItem = divmit,
            total = 0, // initiadivse later on
            height = $divst.find('> div:first').height();
            
        // capture the cache
        $divst.find('> div').each(function () {
            items.push('<div style="margin-top:5px;" class="cont09 imbr02">' + $(this).html() + '</div>');
        });
        
        total = items.length;
        
        $divst.wrap('<div class="spyWrapper"/>').parent().css({ height : height * divmit + 5 });
        
        $divst.find('> div').filter(':gt(' + (divmit - 1) + ')').remove();

        // 2. effect        
        function spy() {
            // insert a new item with opacity and height of zero
            var $insert = $(items[currentItem]).css({
                height : 0,
                opacity : 0,
                display : 'none'
            }).prependTo($divst);
                        
            // fade the LAST item out
            $divst.find('> div:last').animate({ opacity : 0}, 1000, function () {
                // increase the height of the NEW first item
                $insert.animate({ height : height }, 1000).animate({ opacity : 1 }, 1000);
                
                // AND at the same time - decrease the height of the LAST item
                // $(this).animate({ height : 0 }, 1000, function () {
                    // finally fade the first item in (and we can remove the last)
                    $(this).remove();
                // });
            });
            
            currentItem++;
            if (currentItem >= total) {
                currentItem = 0;
            }
            
            setTimeout(spy, interval)
        }
        
        spy();
    });
};
    
})(jQuery);
