<?php
if (!defined('IN_MEDIA')) die("Hack");
function view_pages($type,$ttrow,$limit,$page,$ext='',$apr='',$cat_id=''){
	$total = ceil($ttrow/$limit);
	if ($total <= 1) return '';
	$style_1 = 'class="pagelink" onfocus="this.blur()"';
	$style_2 = 'class="pagecurrent" onfocus="this.blur()"';
    if ($page<>1){
	    if($type=='request') 
		$main .= "<a $style_1 href='javascript:void(0)' onClick='return showRequest(".$limit.",1); return false;'>FIRST</a>&nbsp;";
        elseif($type=='trailer') 
		$main .= "<a $style_1 href='javascript:void(0)' onClick='return showTrailer(".$limit.",".$ext.",1); return false;'>FIRST</a>&nbsp;";
		elseif($type=='film') 
		$main .= "<a $style_1 href=".$ext." onClick='return showFilm(".$ext.",1,".$limit.",".$apr.",".$cat_id."); return false;'>FIRST</a>&nbsp;";
        elseif($type=='comment') 
		$main .= "<a $style_1 href='javascript:void(0)' onClick='return showComment(".$limit.",".$ext.",1); return false;'>FIRST</a>&nbsp;";
    }
	for($num = 1; $num <= $total; $num++){
		if ($num < $page - 1 || $num > $page + 4) 
		continue;
		if($num==$page) 
		$main .= "<a $style_2>$num</a>&nbsp;"; 
        else { 
           if($type=='request') 
		   $main .= "<a $style_1 href='javascript:void(0)' onClick='return showRequest(".$limit.",".$num."); return false;'>$num</a>&nbsp;";
		   elseif($type=='trailer') 
		   $main .= "<a $style_1 href='javascript:void(0)' onClick='return showTrailer(".$limit.",".$ext.",".$num."); return false;'>$num</a>&nbsp;"; elseif($type=='film') 
		   $main .= "<a $style_1 href=".$ext."/".$num." onClick='return showFilm(".$ext.",".$num.",".$limit.",".$apr.",".$cat_id."); return false;'>$num</a>&nbsp;"; 
           elseif($type=='comment') 
		   $main .= "<a $style_1 href='javascript:void(0)' onClick='return showComment(".$limit.",".$ext.",".$num."); return false;'>$num</a>&nbsp;";
       } 		
    }
    if ($page<>$total){
	    if($type=='request') 
		$main .= "<a $style_1 href='javascript:void(0)' onClick='return showRequest(".$limit.",".$total."); return false;'>LAST</a>";      
		elseif($type=='trailer') 
		$main .= "<a $style_1 href='javascript:void(0)' onClick='return showTrailer(".$limit.",".$ext.",".$total."); return false;'>LAST</a>"; 
        elseif($type=='film') 
		$main .= "<a $style_1 href=".$ext."/".$total." onClick='return showFilm(".$ext.",".$total.",".$limit.",".$apr.",".$cat_id."); return false;'>LAST</a>"; 
        elseif($type=='comment') 
		$main .= "<a $style_1 href='javascript:void(0)' onClick='return showComment(".$limit.",".$ext.",".$total."); return false;'>LAST</a>"; 
    }
  return $main;
}
?>