<?php
if (!defined('IN_MEDIA')) die("Hack");
//SEO Link
$link_href=".";
if ($value[1]=='news') {
	$news_id = $value[2];
	$sql = "SELECT * FROM ".$tb_prefix."news where news_id = '$news_id'";
	$q = $mysql->query($sql);
	$num = $mysql->num_rows($q);
	$rs = $mysql->fetch_array($q);
	if (!$num) header("Location: ".$link_href.'/error.html');
	$news_viewed = $rs['news_viewed'];
	$sql2 = "update ".$tb_prefix."news set news_viewed = news_viewed+1 where news_id = $news_id";
	$mysql->query($sql2);
# info new
	$htm = $temp->get_htm('news_details');
	$main = $temp->replace_value($htm,
			array(
				'news.STT'			=> $i+1,
				'news.ID'			=> $rs['news_id'],
				'news.URL'			=> $link_href."/news/info/".replace($rs['news_id']),
				'news.CUT_NAME'		=> cut_string($rs['news_name'],20),
				'news.NAME'		=> $rs['news_name'],
				'news.VIEWED'		=> $rs['news_viewed'],
				'news.IMG'			=> check_img($rs['news_img']),
				'news.QUOTE'		=> $rs['news_quote'],
				'news.CONTENT'		=> text_tidy( $rs['news_content']),
				'news.DATE'		=> $rs['news_date'],
			)
		);

# other new
	$h['num_tag'] = $temp->get_block_from_htm($htm,'num_tag',1);
	$h['start_tag'] = $temp->get_block_from_htm($htm,'start_tag',1);
	$h['end_tag'] = $temp->get_block_from_htm($htm,'end_tag',1);
	$h['row'] = $temp->get_block_from_htm($htm,'row',1);
	$sql = "SELECT * FROM ".$tb_prefix."news where news_id <> $news_id order by news_id desc LIMIT 0,10";
	$q = $mysql->query($sql);

	$i = 0;
	while ($rs2 = $mysql->fetch_array($q)) {
		if ($h['start_tag'] && fmod($i,$h['num_tag']) == 0) $news_list .= $h['start_tag'];
		$news_list .= $temp->replace_value($h['row'],
			array(
				'news.URL'			=> $link_href."/news/".$rs2['news_id']."/".replace($rs2['news_name_ascii']),
				'news.CUT_NAME'		=> cut_string($rs2['news_name'],20),
				'news.NAME'		=> $rs2['news_name'],
			)
		);
		if ($h['end_tag'] && fmod($i,$h['num_tag']) == $h['num_tag'] - 1) $news_list .= $h['end_tag'];
		$i++;
	}
	$main = $temp->replace_blocks_into_htm($main,array(
		'news_list' 		=> $news_list
		)
	);
    $web_keywords_main = $web_title_main = check_data($rs['news_name'])." || ";
}
?>