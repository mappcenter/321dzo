<?php
if (!defined('IN_MEDIA')) die("Hacking attempt");
function cut_str($str_cut,$str_c,$val)
{	
	$url=split($str_cut,$str_c);
	$urlv=$url[$val];
	return $urlv;
}

function encode($str){
	$t = gmdate("i", time()+7*3600);
	$t=($t+1234560);
	$t=$str.'_'.$t;
	$t= str_replace(array('9','8','7','6','5','4','3','2','1','0','_'),array('a','b','c','d','e','g','h','k','v','u','w'),$t);
	return $t;
}
function get_link_total($url,$type) {
	global $web_link;
	$link=$url;
	$t="";
	
   
	if (preg_match('#www.veoh.com\/videodetails2\.swf\?permalinkId=(.*?)#s', $url) || preg_match('#www.veoh.com\/veohplayer\.swf\?permalinkId=(.*?)#s', $url)){
		$id = cut_str('=',$url,1);
		$id = cut_str('&',$id,0);
		$link='http://thienduongviet.org/getlink/veoh/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?autostart=true&file='.$link;
    }
	
    elseif (preg_match('#veoh.com/(.*?)#s', $url, $id_sr)){
		//$id = $id_sr[1];
		//$url = "http://www.veoh.com/static/swf/webplayer/WebPlayer.swf?version=AFrontend.5.4.0.1.1002&permalinkId=".$id."&player=videodetailsembedded&videoAutoPlay=1";
		$linkvideo=explode('/', $link);
		$num=count($linkvideo);
		$id=$linkvideo[$num-1];
		$link='http://thienduongviet.org/getlink/veoh/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?autostart=true&file='.$link;
    }
	else if (preg_match('#www.2shared.com/file/(.*?)#s', $url, $id_sr)){
		$linkvideo=explode('/', $link);
		$num=count($linkvideo);
		$id=($linkvideo[$num-3].'-'.$linkvideo[$num-2].'-'.$linkvideo[$num-1]);
		$link='http://phimnhanh.net/grab/2shared/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?autostart=true&file='.$link;
	}
    elseif (preg_match("#blog.com.vn/Video/([^/_]+)_([^/.]+).html#",$url,$id_sr)) {
		$id = $id_sr[2];
		$link='http://namdinh.org/media/blog/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?autostart=true&file='.$link;
    }
	elseif(preg_match('#http:\/\/clip.vn\/watch\/([^/,]+),([^/]+)#', $url, $id_sr)) {
		$id = $id_sr[2];
		$url = 'http://clip.vn/w/'.$id.',a';
		$t="f";
	}
    
    elseif (preg_match("#youtube.com/watch([^/]+)#",$url,$id_sr)) {
		$id = cut_str('=',$url,1);
		$url="http://www.youtube.com/v/".$id;

    }

	elseif (preg_match("#youtube.com/feeds/api/playlists/([^/]+)#",$url,$id_sr)) {

		$id = cut_str('/',$url,6);

		$url="http://www.youtube.com/p/".$id;

		

    }

	elseif (preg_match("#youtube.com/view_play_list([^/]+)#",$url,$id_sr)) {

		$id = cut_str('=',$url,1);

		$link='http://thienduongviet.org/getlink/youtube/playlist'.$id.'.html';

		$link2='http://thienduongviet.org/getlink/youtube/playlist'.$id.'.xml';

		$url=$web_link.'/'.'player.swf?autostart=true&playlist=over&file='.$link2;

		

   
		

    }
	elseif (preg_match("#sevenload.com/videos/([^/-]+)-([^/]+)#",$url,$id_sr)) {
		//$id = $id_sr[1];
		//$url = "http://static.sevenload.com/swf/player/player.swf?v=142&configPath=http%3A%2F%2Fflash.sevenload.com%2Fplayer%3FportalId%3Den%26autoplay%3D0%26mute%3D0%26itemId%3D".$id."&amp;locale=en_US&amp;autoplay=0&amp;environment=";
		$linkvideo=explode('/', $link);
		$num=count($linkvideo);
		$link=$linkvideo[$num-1];
		$id=explode('-', $link);
		$link='http://namdinh.org/media/sevenload/'.$id[0].'.flv';
		$url=$web_link.'/player.swf?file='.$link;
		
   
	
	}
	else if (preg_match("#http://movie.zing.vn/Movie/xem-online/(.*?)#s", $url)){
		$link=str_replace(array('http://movie.zing.vn/Movie/xem-online/','.html'),array('http://thienduongviet.org/getlink/zingm/','.wpl'),$url);
		$url=$link;
	}
	else if (preg_match("#video.timnhanh.com/xem-clip/([^/]+)#",$url,$id_sr)) {
		$id = $id_sr[1];
		$link='http://vn1.vtoday.net/vtimnhanh/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?autostart=true&file='.$link;
	}
	else if (preg_match("#http://video.yume.vn/xem-clip/([^/]+)#",$url,$id_sr)) {
		$id = $id_sr[1];
		$link='http://vn1.vtoday.net/vtimnhanh/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?autostart=true&file='.$link;
		
		}
		else if (preg_match("#http://video.yume.vn/video-clip/([^/]+)#",$url,$id_sr)) {
		$id = $id_sr[1];
		$link='http://vn1.vtoday.net/vtimnhanh/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?autostart=true&file='.$link;
		
		}
	else if (preg_match("#phimf.com/f/(.*?)#s", $url)){
		$link=str_replace('http://phimf.com/f/','http://thienduongviet.org/getlink/phimf/',$url);
		$url=$link.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$url;
		
	}
	else if (preg_match("#badongo.com/vid/(.*?)#s", $url,$id_sr)){
		$link=str_replace('http://badongo.com/vid/','http://thienduongviet.org/getlink/badongo/',$id);
		$id=cut_str('/',$url,4);

		$link2='http://rongitvn.com/grab/badongo.php?id='.$id;

	$url=$web_link.'/'.'player.swf?autostart=true&type=video&file='.$link2;
		
	}
	else if (preg_match("#megavideo.com/\?v=(.*?)#s", $url,$id_sr)){
		$id=cut_str('=',$url,1);
		$t = gmdate("i", time()+7*3600);
		$t=($t+1234560);
		$t= str_replace(array('9','8','7','6','5','4','3','2','1','0'),array('a','b','c','d','e','g','h','k','v','u'),$t);
		$link='http://thienduongviet.org/getlink/mega/'.$id.'_'.$t.'.flv';
		//$link='http://thienduongviet.org/getlink/megavideo/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link.'&autostart=true';
		$url='http://wwwstatic.megavideo.com/mv_player.swf?v='.$id;
		
	}
	else if (preg_match("#^http://www.metacafe.com/watch/(.*?)#s", $url)){
		$id = cut_str('/',$url,4);
		$link='http://thienduongviet.org/getlink/metacafe/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link.'&autostart=true';
	}
	else if (preg_match("#^http://timvui.vn/video/(.*?)#s", $url)){
		$id = cut_str('view/',$url,1);
		$id = cut_str('\.',$id,0);
		$link='http://let.vn/grab/timvui/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?autostart=true&file='.$link;
	}
	else if (preg_match("#video.baamboo.com(.*?)#s", $url)){
			$t = cut_str('/',$url,4);
			$id =cut_str('/',$url,6);
			$link='http://thienduongviet.org/getlink/baamboo/'.$id.'_'.$t.'.flv';
			$url=$web_link.'/'.'player.swf?file='.$link.'&autostart=true';
	}
	else if (preg_match("#video.baamboo.com(.*?)#s", $url)){
			$t = cut_str('/',$url,4);
			$id =cut_str('/',$url,6);
			$link='http://thienduongviet.org/getlink/baamboo/'.$id.'_'.$t.'.flv';
			$url=$web_link.'/'.'player.swf?file='.$link.'&autostart=true';
	}
	else if (preg_match("#^http://www.sendspace.com/file/(.*?)#s", $url)){
		$id = cut_str('/',$link,4);
		$link2='http://web4v.com/grab/sendspace/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?autostart=true&file='.$link2;
	}

	if (($t=="") && (substr_count($url,$web_link.'/player.swf') != 0)) 
		//$url=$url.'&plugins=captions-1&captions.file='.$web_link.'/'.'captions.xml&captions.back=ffff&logo='.$web_link.'/logo.png';
		$url=$url.'&logo='.$web_link.'/logo.png';
	if ($type==0) $trave=$url;
	elseif ($type==1) $trave=$link;
return $trave;
}
?>