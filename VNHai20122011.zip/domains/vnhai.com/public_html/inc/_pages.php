<?php
if (!defined('IN_MEDIA')) die("Hack");
function view_pages($type,$ttrow,$limit,$page,$ext='',$apr='',$cat_id=''){
	$total = ceil($ttrow/$limit);
	if ($total <= 1) return '';
	$style_1 = 'onfocus="this.blur()"';
	$style_2 = 'onfocus="this.blur()"';
	$ext = str_replace('.html','',$ext);
    if ($page<>1){
	    if($type=='request') 
		$main .= "<span><a $style_1 href='javascript:void(0)' onClick='return showRequest(".$limit.",1); return false;'>|<<</a></span>";
        elseif($type=='trailer') 
		$main .= "<span><a $style_1 href='javascript:void(0)' onClick='return showTrailer(".$limit.",".$ext.",1); return false;'>|<<</a></span>";
		elseif($type=='film') 
		$main .= "<span><a $style_1 href=".$ext."1.html onClick='return showFilm(".$ext.",1,".$limit.",".$apr.",".$cat_id."); return false;'>|<<</a></span>";
        elseif($type=='comment') 
		$main .= "<span><a $style_1 href='javascript:void(0)' onClick='return showComment(".$limit.",".$ext.",1); return false;'>|<<</a></span>";
    }
	for($num = 1; $num <= $total; $num++){
		if ($num < $page - 1 || $num > $page + 4) 
		continue;
		if($num==$page) 
		$main .= "<span class=\"currentpage\"><span><img width=\"1px\" height=\"28px\" src=\"/images/blank.gif\" alt=\"\">$num</span></span>"; 
        else { 
           if($type=='request') 
		   $main .= "<span><a $style_1 href='javascript:void(0)' onClick='return showRequest(".$limit.",".$num."); return false;'>$num</a></span>";
		   elseif($type=='trailer') 
		   $main .= "<span><a $style_1 href='javascript:void(0)' onClick='return showTrailer(".$limit.",".$ext.",".$num."); return false;'>$num</a></span>"; 
		   elseif($type=='film') 
		   $main .= "<span><a $style_1 href=".$ext.$num.".html onClick='return showFilm(".$ext.",".$num.",".$limit.",".$apr.",".$cat_id."); return false;'>$num</a></span>"; 
           elseif($type=='comment') 
		   $main .= "<span><a $style_1 href='javascript:void(0)' onClick='return showComment(".$limit.",".$ext.",".$num."); return false;'>$num</a></span>";
       } 		
    }
    if ($page<>$total){
	    if($type=='request') 
		$main .= "<span><a $style_1 href='javascript:void(0)' onClick='return showRequest(".$limit.",".$total."); return false;'>>>|</a></span>";      
		elseif($type=='trailer') 
		$main .= "<span><a $style_1 href='javascript:void(0)' onClick='return showTrailer(".$limit.",".$ext.",".$total."); return false;'>>>|</a></span>"; 
        elseif($type=='film') 
		$main .= "<span><a $style_1 href=".$ext.$total.".html onClick='return showFilm(".$ext.",".$total.",".$limit.",".$apr.",".$cat_id."); return false;'>>>|</a></span>"; 
        elseif($type=='comment') 
		$main .= "<span><a $style_1 href='javascript:void(0)' onClick='return showComment(".$limit.",".$ext.",".$total."); return false;'>>>|</a></span>"; 
    }
  return $main;
}
?>