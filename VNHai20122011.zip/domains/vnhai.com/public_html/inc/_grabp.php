<?php
if (!defined('IN_MEDIA')) die("Hacking attempt");
function cut_str($str_cut,$str_c,$val)
{	
	$url=split($str_cut,$str_c);
	$urlv=$url[$val];
	return $urlv;
}

function encode($str){
	$t = gmdate("i", time()+7*3600);
	$t=($t+1234560);
	$t=$str.'_'.$t;
	$t= str_replace(array('9','8','7','6','5','4','3','2','1','0','_'),array('a','b','c','d','e','g','h','k','v','u','w'),$t);
	return $t;
}
function get_link_total($url) {
	global $web_link;
	$link=$url;
	$t="";
	  if (preg_match('#video.tamtay.vn/play/([0-9]+)#', $url, $id_sr)){
		$id = $id_sr[1];
		$url = "http://video.tamtay.vn/flash/player/flowplayer.swf?config={embeded:true, configFileName: 'http://video.tamtay.vn/play/".$id."/1'}";
    }
      elseif (preg_match('#video.tamtay.vn/play/([0-9]+)#', $url, $id_sr)){
		//$id = $id_sr[1];
		//$url = "http://video.tamtay.vn/flash/player/flowplayer.swf?config={embeded:true, configFileName: 'http://video.tamtay.vn/play/".$id."/1'}";
		$id = cut_str('http://video.tamtay.vn/',$url,1);
		/*$link='http://getlink.thienduongviet.org/tamtayv.php?url='.$id;
		$url=getlink($link);*/
		$id = cut_str('.html',$id,0);
		$link='http://getlink.thienduongviet.org/tamtay/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link.'&autostart=true';
		//$url='http://grab.cua113.com/tamtay-embed/'.$id_sr[1].'.swf';
		
    }
    elseif (preg_match('#veoh.com/browse/videos/category/([^/]+)/watch/([^/]+)#', $url, $id_sr)){
		$id = $id_sr[2];
		$id = $id_sr[2];
		$link='http://namdinh.org/media/veoh/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link.'&autostart=true';
		//$url = "http://www.veoh.com/static/swf/webplayer/WebPlayer.swf?version=AFrontend.5.4.0.1.1002&permalinkId=".$id."&player=videodetailsembedded&videoAutoPlay=1";
    }
	elseif (preg_match('#www.veoh.com\/videodetails2\.swf\?permalinkId=(.*?)#s', $url) || preg_match('#www.veoh.com\/veohplayer\.swf\?permalinkId=(.*?)#s', $url)){
		$id = cut_str('=',$url,1);
		$id = cut_str('&',$id,0);
		$link='http://namdinh.org/media/veoh/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link.'&autostart=true';
    }
	
    elseif (preg_match('#veoh.com/(.*?)#s', $url, $id_sr)){
		//$id = $id_sr[1];
		//$url = "http://www.veoh.com/static/swf/webplayer/WebPlayer.swf?version=AFrontend.5.4.0.1.1002&permalinkId=".$id."&player=videodetailsembedded&videoAutoPlay=1";
		$linkvideo=explode('/', $link);
		$num=count($linkvideo);
		$id=$linkvideo[$num-1];
		$link='http://namdinh.org/media/veoh/v'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link.'&autostart=true';
    }
    elseif (preg_match("#blog.com.vn/Video/([^/_]+)_([^/.]+).html#",$url,$id_sr)) {
		$id = $id_sr[2];
		$url = "http://blog.com.vn/embed/f/f/".$id;
		$link='http://getlink.thienduongviet.org/blogvn/'.$id.'.flv';
		$t="f";
    }
	elseif(preg_match('#http:\/\/clip.vn\/watch\/([^/,]+),([^/]+)#', $url, $id_sr)) {
		$id = $id_sr[2];
		$url = 'http://clip.vn/w/'.$id.',a';
		$t="f";
	}
    elseif (preg_match("#dailymotion.com/(.*?)#s",$url,$id_sr)) {
		$linkvideo=explode('/', $url);
		$num=count($linkvideo);
		$link=$linkvideo[$num-1];
		$id=explode('_', $link);
		$id=explode('&', $id[0]);
		$link='http://getlink.thienduongviet.org/daily/'.$id[0].'.flv';
		$url='http://www.dailymotion.com/swf/'.$id[0];
		//$url=$web_link.'/'.'player.swf?file='.$link.'&autostart=true';
		
    }
    elseif (preg_match("#youtube.com/v/([^/]+)#",$url,$id_sr)) {
		$id = $id_sr[1];
		$url = "http://www.youtube.com/watch?v=".$id;
		
    }
	elseif (preg_match("#youtube.com/view_play_list([^/]+)#",$url,$id_sr)) {
		$id = cut_str('=',$url,1);
		/*$url = "http://www.youtube.com/watch?v=".$id;*/
		$link='http://getlink.thienduongviet.org/youtube/playlist/'.$id.'.html';
		$link2='http://getlink.thienduongviet.org/youtube/playlist/'.$id.'.xml';
		$url=$web_link.'/'.'player.swf?file='.$link2.'&autostart=true&playlist=over&repeat=list&plugins=captions-1';
		
		
    }
	elseif (preg_match("#sevenload.com/videos/([^/-]+)-([^/]+)#",$url,$id_sr)) {
		//$id = $id_sr[1];
		//$url = "http://static.sevenload.com/swf/player/player.swf?v=142&configPath=http%3A%2F%2Fflash.sevenload.com%2Fplayer%3FportalId%3Den%26autoplay%3D0%26mute%3D0%26itemId%3D".$id."&amp;locale=en_US&amp;autoplay=0&amp;environment=";
		$linkvideo=explode('/', $link);
		$num=count($linkvideo);
		$link=$linkvideo[$num-1];
		$id=explode('-', $link);
		$link='http://getlink.thienduongviet.org/sevenload/'.$id[0].'.flv';
		$url=$web_link.'/player.swf?file='.$link;
		
    }
	else if (preg_match("#video.zing.vn(.*?)#s", $url)){
		$s = explode(".",$url);
    	$id = intval($s[3]);
		$link='http://power.thienduongviet.org/zingv/'.encode($id).'/'.$id.'.flv';
		$url='http://power.thienduongviet.org/zingv/'.encode($id).'/'.$id.'.swf';		
	}
	else if (preg_match("#http://movie.zing.vn/Movie/xem-online/(.*?)#s", $url)){
		$link=str_replace(array('http://movie.zing.vn/Movie/xem-online/','.html'),array('http://getlink.thienduongviet.org/zingm/','.wpl'),$url);
		$url=$link;
	}
	else if (preg_match("#phimf.com/f/(.*?)#s", $url)){
		$link=str_replace('http://phimf.com/f/','http://getlink.thienduongviet.org/phimf/',$url);
		$url=$link.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$url;
		
    }
    elseif (preg_match('#badongo.com/vid/([^/]+)#', $url, $id)){
		$url = "http://namdinh.org/media/badongo/".$id[1].".flv";
	
		
	}
	else if (preg_match("#megavideo.com/\?v=(.*?)#s", $url,$id_sr)){
		$id=cut_str('=',$url,1);
		$t = gmdate("i", time()+7*3600);
		$t=($t+1234560);
		$t= str_replace(array('9','8','7','6','5','4','3','2','1','0'),array('a','b','c','d','e','g','h','k','v','u'),$t);
		$link='http://getlink.thienduongviet.org/mega/'.$id.'_'.$t.'.flv';
		//$link='http://getlink.thienduongviet.org/megavideo/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link.'&autostart=true';
		$url='http://wwwstatic.megavideo.com/mv_player.swf?v='.$id;
		
	}
	else if (preg_match("#^http://www.metacafe.com/watch/(.*?)#s", $url)){
		$id = cut_str('/',$url,4);
		$link='http://getlink.thienduongviet.org/metacafe/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link.'&autostart=true';
	}
	else if (preg_match("#^http://timvui.vn/video/(.*?)#s", $url)){
		$id = cut_str('view/',$url,1);
		$id = cut_str('\.',$id,0);
		$link='http://getlink.thienduongviet.org/timvui/'.$id.'.flv';
		$url=$web_link.'/'.'player.swf?file='.$link.'&autostart=true';
	}
	else if (preg_match("#nhaccuatui.com(.*?)#s", $url)){
			$id = cut_str('=',$url,1);
			$link='http://getlink.thienduongviet.org/nct/'.$id.'.flv';
			$url='http://www.nhaccuatui.com/m2/'.$id;
			//$url=$web_link.'/'.'player.swf?file='.$link.'&autostart=true';
	}
	else if (preg_match("#video.baamboo.com(.*?)#s", $url)){
			$t = cut_str('/',$url,4);
			$id =cut_str('/',$url,6);
			$link='http://getlink.thienduongviet.org/baamboo/'.$id.'_'.$t.'.flv';
			$url=$web_link.'/'.'player.swf?file='.$link.'&autostart=true';
	}
	else if (preg_match("#video.baamboo.com(.*?)#s", $url)){
			$t = cut_str('/',$url,4);
			$id =cut_str('/',$url,6);
			$link='http://getlink.thienduongviet.org/baamboo/'.$id.'_'.$t.'.flv';
			$url=$web_link.'/'.'player.swf?file='.$link.'&autostart=true';
	}

	    elseif (preg_match('#www.sendspace.com/file/([^/]+)#', $url, $id)){
		$url = "http://namdinh.org/media/sendspace/".$id[1].".flv";
			
	}

	if (($t=="") && (substr_count($url,$web_link.'/pla1yer.swf') != 0)) 
		//$url=$url.'&plugins=captions-1&captions.file='.$web_link.'/'.'captions.xml&captions.back=ffff&logo='.$web_link.'/logo.png';
		$url=$url.'&logo='.$web_link.'/logo.png';
	if ($type==0) $trave=$url;
	elseif ($type==1) $trave=$link;
return $trave;
}
?>
